package controllers

import (
	"github.com/astaxie/beego"
	"github.com/gorilla/websocket"
	"fmt"
	"eth_block_project/eth"
	"strings"
	"time"
	"math/big"
)

// 存放客户端的连接
var clients = make(map[*websocket.Conn]bool)
// 升级为ws
var upgrader = websocket.Upgrader{}

// 通道
var acccounts_chan = make(chan map[string]interface{})

type EthController struct {
	beego.Controller
}


// 首页页面

func (e *EthController)Index()  {

	total,err := eth.GetTotal()
	if err != nil {
		fmt.Println(err)
	}
	e.Data["total"] = total
	e.TplName = "index.html"
	
}


// 获取投注信息
func (e *EthController) PostTouZhu()  {
	username := e.GetString("username")
	pwd := e.GetString("pwd")
	num1 := e.GetString("num1")
	num2 := e.GetString("num2")
	num3 := e.GetString("num3")
	num4 := e.GetString("num4")
	num5 := e.GetString("num5")


	nums := num1 + " " + num2 + " " + num3 + " " + num4 + " " + num5
	// 提交到以太坊合约
	tx,is_ok := eth.TouZhu(strings.ToLower(username),pwd,nums)
	if is_ok {
		ret_data := map[string]interface{}{
			"code":200,
			"msg":"投注成功",
			"data":tx.Hash(),
		}
		e.Data["json"] = ret_data
		e.ServeJSON()
	}

	ret_data := map[string]interface{}{
		"code":400,
		"msg":"投注失败",

	}
	e.Data["json"] = ret_data
	e.ServeJSON()


}


// 实时获取投注账户及投注号码,返回json
func (e *EthController)GetTouZhuAccounts()  {


	//accounts := []map[string]interface{}{
	//	{
	//		"addr":"0x00",
	//		"nums":[]int{2,4,1,2,2},
	//	},
	//	{
	//		"addr":"0x01",
	//		"nums":[]int{1,4,1,2,3},
	//	},
	//	{
	//		"addr":"0x02",
	//		"nums":[]int{1,2,1,2,2},
	//	},
	//
	//}




	ws,err := upgrader.Upgrade(e.Ctx.ResponseWriter,e.Ctx.Request,nil)
	if err != nil {
		fmt.Println(err)
	}
	// 放到clients中
	clients[ws] = true

	for {

		// 第一种方式：使用toolbox定时任务
		time.Sleep(time.Second)


		// 第二种方式
		// 每隔5秒获取合约的投注信息
		//time.Sleep(time.Second * 5)
		// 获取投注信息
		//accounts := eth.GetTouZhuAccounts()
		//ret_map := map[string]interface{}{
		//	"accounts":accounts,
		//}
		//
		//
		//// 把数据写入通道
		//acccounts_chan <- ret_map

	}

	//
	//e.Data["json"] = ret_map
	//e.ServeJSON()

}


// 查询页面
func (e *EthController) Search()  {
	e.TplName = "search.html"
	
}

// 获取查询数据
func (e *EthController)GetAcountInfo()  {

	addr := e.GetString("addr")

	// 把addr传到智能合约，返回改用户的账户余额和投注号码，
	// 替换下面的balance、nums
	balance,err := eth.GetAccountBalance(addr)

	if err != nil {
		balance = big.NewInt(0)
	}

	accounts := eth.GetTouZhuAccounts()
	//accounts := []map[string]interface{}{
	//	{
	//		"addr":"0x00",
	//		"nums":[]int{2,4,1,2,2},
	//	},
	//	{
	//		"addr":"0x01",
	//		"nums":[]int{1,4,1,2,3},
	//	},
	//	{
	//		"addr":"0x02",
	//		"nums":[]int{1,2,1,2,2},
	//	},
	//
	//}


	var nums []interface{}
	for _,account_map := range accounts {
		addr_ret := account_map["addr"]
		if addr_ret == addr {
			num := account_map["nums"]
			nums = append(nums, num)
		}

	}


	//nums := [][]int{
	//	{
	//		1,2,3,4,3,
	//	},
	//	{
	//		2,2,3,4,1,
	//	},
	//	{
	//		3,2,3,4,3,
	//	},
	//}

	ret_map := map[string]interface{}{}
	if addr == "" {
		ret_map = map[string]interface{}{
			"addr":addr,
			"balance":0,
			"nums":[][]int{},
		}
	}else {
		ret_map = map[string]interface{}{
			"addr":addr,
			"balance":balance,
			"nums":nums,
		}
	}


	fmt.Println(ret_map)
	e.Data["account_info"] = ret_map
	e.TplName = "search.html"

	
}


// 开奖页面
func (e *EthController)KaiJiang()  {
	total,err := eth.GetTotal()
	if err != nil {
		total = 0
	}
	e.Data["total"] = total
	e.TplName = "kaijiang.html"

}

// 开奖功能
func (e *EthController)DoKaiJiang()  {
	ret_num,total,err := eth.KaiJiangApi()
	fmt.Println("==============")
	fmt.Println(err)
	money,err := eth.GetTotalMoney(total)
	//fmt.Println("==============")
	fmt.Println(err)
	time.Sleep(time.Second * 15)

	if err != nil {
		e.Data["ret_num"] = []*big.Int{}
		e.Data["admin"] = "ee7ec7e6b303601ff62e947664710c552c3f7942"
		e.Data["total"] = 0
		e.Data["money"] = 0

	}else {

		e.Data["ret_num"] = ret_num
		e.Data["admin"] = "ee7ec7e6b303601ff62e947664710c552c3f7942"
		e.Data["total"] = total
		e.Data["money"] = money
	}


	e.TplName = "kaijiang.html"


}
// 智能合约页面
func (e *EthController) Contract()  {
	e.TplName = "contract.html"
	
}