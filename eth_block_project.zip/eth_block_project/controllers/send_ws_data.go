package controllers

func init() {
	go SendWsData()
}

func SendWsData()  {
	for {  // 保证一次协程调用完成
		accounts := <- acccounts_chan

		for client := range clients {
			err := client.WriteJSON(accounts)
			if err != nil {
				client.Close()
				delete(clients,client)
			}
		}

	}

}