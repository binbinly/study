package controllers

import (
	"github.com/astaxie/beego/toolbox"
	"eth_block_project/eth"
)

func InitTask()  {
	// 定时
	//time.Sleep(time.Second * 5)  // todo beego定时任务

	task := toolbox.NewTask("GetAccountsAndWtChan","0/3 * * * * *",GetAccountsAndWtChan)

	toolbox.AddTask("GetAccountsAndWtChan",task)

}


// 读取投注信息并写入通道
func GetAccountsAndWtChan() error  {
	// 获取投注信息
	accounts := eth.GetTouZhuAccounts()
	ret_map := map[string]interface{}{
		"accounts":accounts,
	}


	// 把数据写入通道
	acccounts_chan <- ret_map
	return nil
}
