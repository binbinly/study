package eth

import (
	"github.com/ethereum/go-ethereum/ethclient"
	"github.com/ethereum/go-ethereum/common"
)



var Lottery_obj *Lottery
var err error

func init()  {

	client,err := ethclient.Dial("http://127.0.0.1:8545")
	if err != nil {
		panic("连接以太坊智能合约出错")
	}

	// 合约地址
	contract_addr := "0x0b5E9f7295002fcC7aF2647201FC60337F0eE239"
	common_contract_addr := common.HexToAddress(contract_addr)

	Lottery_obj ,err = NewLottery(common_contract_addr,client)

	if err != nil {
		panic("实例化合约出错")
	}

}



