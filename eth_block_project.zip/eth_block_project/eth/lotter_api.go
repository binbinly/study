package eth

import (
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"strings"
	"math/big"

	"io/ioutil"
	"eth_block_project/utils"
	"github.com/ethereum/go-ethereum/core/types"
	"fmt"
	"time"
)

// 获取管理员账户地址
func GetOwner() (owner common.Address,err error) {

	owner,err = Lottery_obj.Owner(nil)
	if err != nil {
		return owner,err
	}

	return owner,nil
}

// 获取彩票期数
func GetTotal() (total uint8,err error) {

	total,err = Lottery_obj.Total(nil)
	if err != nil {
		return total,err
	}

	return total,nil


}


// 投注
func TouZhu(username string,pwd string,nums string) (tx *types.Transaction, is_ok bool) {

	// 去掉0x，然后转成小写，根据最后的一部分读取文件
	//"0xeE7EC7E6B303601Ff62e947664710C552c3F7942"
	//UTC--2021-03-29T07-05-04.559032400Z--ee7ec7e6b303601ff62e947664710c552c3f7942
	// 读取账户json文件

	// die一定不要忘了后面的/
	dir := "eth/lottery_data/keystore/"
	filename,exist := utils.GetFileName(dir,username)

	if exist {

		var keystore_path string = dir + filename

		byte_data,err_file := ioutil.ReadFile(keystore_path)


		// 初始化交易信息
		auth,err_auth := bind.NewTransactorWithChainID(strings.NewReader(string(byte_data)),pwd,big.NewInt(15))

		if err_auth != nil {
			panic("初始化交易出错")
		}

		if err_file != nil {
			panic("读取key出错")
		}

		auth.GasLimit = uint64(3000000)
		auth.GasPrice = big.NewInt(20000)
		auth.Value = big.NewInt(1000000000000000000)


		tx,err := Lottery_obj.TouZhu(auth,username,nums)
		if err != nil {
			return tx,false
		}
		return tx,true

	}else {
		return tx,false
	}


}


// 获取投注信息
func GetTouZhuAccounts() ([]map[string]interface{}) {

	addrs_map := []map[string]interface{}{}

	var i int64 = 0
	for {  // 一定要注意退出循环
		addr_struct,err :=Lottery_obj.Accounts(nil,big.NewInt(i))
		if err != nil {
			break
		}
		addr := addr_struct.Addr
		nums := addr_struct.Nums
		new_nums := strings.Split(nums," ")
		addr_map := map[string]interface{}{}
		addr_map["addr"] = addr
		addr_map["nums"] = new_nums
		addrs_map = append(addrs_map, addr_map)
		i ++
	}

	return addrs_map


}



// 获取指定账户的余额
func GetAccountBalance(addr string) (*big.Int,error) {

	balance,err := Lottery_obj.GetAccountBalance(nil,common.HexToAddress(addr))
	return balance,err

}


// 开奖结果，一个是开奖号码，一个奖励金额
func KaiJiangApi()  ([]*big.Int,uint8,error){


	total,_ := GetTotal()

	keystory_path := "eth/lottery_data/keystore/UTC--2021-03-29T07-05-04.559032400Z--ee7ec7e6b303601ff62e947664710c552c3f7942"
	byte_data,err_file := ioutil.ReadFile(keystory_path)

	pwd := "12345678"
	// 初始化交易信息
	auth,err_auth := bind.NewTransactorWithChainID(strings.NewReader(string(byte_data)),pwd,big.NewInt(15))

	if err_auth != nil {
		panic("初始化交易出错")
	}

	if err_file != nil {
		panic("读取key出错")
	}

	_,err := Lottery_obj.Kaijiang(auth)

	if err != nil {
		panic(err)
	}
	time.Sleep(time.Second * 8)
	ret_num := []*big.Int{}

	fmt.Println(err)
	fmt.Println(total)
	if err == nil { // 没有发生错误
		//var i int64 = 0
		for i:=0;i<5;i++ {  // 0 1 2 3 4

			// 第一个uint8是彩票期数，第二个数数字的脚标
			num,err := Lottery_obj.HistoryRetNums(nil,total,big.NewInt(int64(i)))

			if err != nil {
				return ret_num,total,err
			}
			ret_num = append(ret_num, num)
		}

		return ret_num,total,nil
	}

	return ret_num,total,err


}

// 获取当前奖池金额
func GetTotalMoney(total uint8) (*big.Int,error) {
	money,err := Lottery_obj.HistoryTotalMoney(nil,total)
	time.Sleep(time.Second * 3)
	return money,err

}

