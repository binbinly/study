// Code generated - DO NOT EDIT.
// This file is a generated binding and any manual changes will be lost.

package eth

import (
	"math/big"
	"strings"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/event"
)

// Reference imports to suppress errors if they are not otherwise used.
var (
	_ = big.NewInt
	_ = strings.NewReader
	_ = ethereum.NotFound
	_ = bind.Bind
	_ = common.Big1
	_ = types.BloomLookup
	_ = event.NewSubscription
)

// LotteryABI is the input ABI used to generate the binding from.
const LotteryABI = "[{\"constant\":false,\"inputs\":[],\"name\":\"Kaijiang\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"new_addr\",\"type\":\"string\"},{\"name\":\"new_nums\",\"type\":\"string\"}],\"name\":\"TouZhu\",\"outputs\":[],\"payable\":true,\"stateMutability\":\"payable\",\"type\":\"function\"},{\"inputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"accounts\",\"outputs\":[{\"name\":\"addr\",\"type\":\"string\"},{\"name\":\"nums\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"acount\",\"outputs\":[{\"name\":\"addr\",\"type\":\"string\"},{\"name\":\"nums\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"addr\",\"type\":\"address\"}],\"name\":\"GetAccountBalance\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"uint8\"},{\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"history_accounts\",\"outputs\":[{\"name\":\"addr\",\"type\":\"string\"},{\"name\":\"nums\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"uint8\"},{\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"history_ret_nums\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"uint8\"}],\"name\":\"history_total_money\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"owner\",\"outputs\":[{\"name\":\"\",\"type\":\"address\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"name\":\"ret_nums\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"total\",\"outputs\":[{\"name\":\"\",\"type\":\"uint8\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"}]"

// Lottery is an auto generated Go binding around an Ethereum contract.
type Lottery struct {
	LotteryCaller     // Read-only binding to the contract
	LotteryTransactor // Write-only binding to the contract
	LotteryFilterer   // Log filterer for contract events
}

// LotteryCaller is an auto generated read-only Go binding around an Ethereum contract.
type LotteryCaller struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// LotteryTransactor is an auto generated write-only Go binding around an Ethereum contract.
type LotteryTransactor struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// LotteryFilterer is an auto generated log filtering Go binding around an Ethereum contract events.
type LotteryFilterer struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// LotterySession is an auto generated Go binding around an Ethereum contract,
// with pre-set call and transact options.
type LotterySession struct {
	Contract     *Lottery          // Generic contract binding to set the session for
	CallOpts     bind.CallOpts     // Call options to use throughout this session
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// LotteryCallerSession is an auto generated read-only Go binding around an Ethereum contract,
// with pre-set call options.
type LotteryCallerSession struct {
	Contract *LotteryCaller // Generic contract caller binding to set the session for
	CallOpts bind.CallOpts  // Call options to use throughout this session
}

// LotteryTransactorSession is an auto generated write-only Go binding around an Ethereum contract,
// with pre-set transact options.
type LotteryTransactorSession struct {
	Contract     *LotteryTransactor // Generic contract transactor binding to set the session for
	TransactOpts bind.TransactOpts  // Transaction auth options to use throughout this session
}

// LotteryRaw is an auto generated low-level Go binding around an Ethereum contract.
type LotteryRaw struct {
	Contract *Lottery // Generic contract binding to access the raw methods on
}

// LotteryCallerRaw is an auto generated low-level read-only Go binding around an Ethereum contract.
type LotteryCallerRaw struct {
	Contract *LotteryCaller // Generic read-only contract binding to access the raw methods on
}

// LotteryTransactorRaw is an auto generated low-level write-only Go binding around an Ethereum contract.
type LotteryTransactorRaw struct {
	Contract *LotteryTransactor // Generic write-only contract binding to access the raw methods on
}

// NewLottery creates a new instance of Lottery, bound to a specific deployed contract.
func NewLottery(address common.Address, backend bind.ContractBackend) (*Lottery, error) {
	contract, err := bindLottery(address, backend, backend, backend)
	if err != nil {
		return nil, err
	}
	return &Lottery{LotteryCaller: LotteryCaller{contract: contract}, LotteryTransactor: LotteryTransactor{contract: contract}, LotteryFilterer: LotteryFilterer{contract: contract}}, nil
}

// NewLotteryCaller creates a new read-only instance of Lottery, bound to a specific deployed contract.
func NewLotteryCaller(address common.Address, caller bind.ContractCaller) (*LotteryCaller, error) {
	contract, err := bindLottery(address, caller, nil, nil)
	if err != nil {
		return nil, err
	}
	return &LotteryCaller{contract: contract}, nil
}

// NewLotteryTransactor creates a new write-only instance of Lottery, bound to a specific deployed contract.
func NewLotteryTransactor(address common.Address, transactor bind.ContractTransactor) (*LotteryTransactor, error) {
	contract, err := bindLottery(address, nil, transactor, nil)
	if err != nil {
		return nil, err
	}
	return &LotteryTransactor{contract: contract}, nil
}

// NewLotteryFilterer creates a new log filterer instance of Lottery, bound to a specific deployed contract.
func NewLotteryFilterer(address common.Address, filterer bind.ContractFilterer) (*LotteryFilterer, error) {
	contract, err := bindLottery(address, nil, nil, filterer)
	if err != nil {
		return nil, err
	}
	return &LotteryFilterer{contract: contract}, nil
}

// bindLottery binds a generic wrapper to an already deployed contract.
func bindLottery(address common.Address, caller bind.ContractCaller, transactor bind.ContractTransactor, filterer bind.ContractFilterer) (*bind.BoundContract, error) {
	parsed, err := abi.JSON(strings.NewReader(LotteryABI))
	if err != nil {
		return nil, err
	}
	return bind.NewBoundContract(address, parsed, caller, transactor, filterer), nil
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Lottery *LotteryRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Lottery.Contract.LotteryCaller.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Lottery *LotteryRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Lottery.Contract.LotteryTransactor.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Lottery *LotteryRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Lottery.Contract.LotteryTransactor.contract.Transact(opts, method, params...)
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Lottery *LotteryCallerRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Lottery.Contract.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Lottery *LotteryTransactorRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Lottery.Contract.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Lottery *LotteryTransactorRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Lottery.Contract.contract.Transact(opts, method, params...)
}

// GetAccountBalance is a free data retrieval call binding the contract method 0x28646213.
//
// Solidity: function GetAccountBalance(address addr) view returns(uint256)
func (_Lottery *LotteryCaller) GetAccountBalance(opts *bind.CallOpts, addr common.Address) (*big.Int, error) {
	var out []interface{}
	err := _Lottery.contract.Call(opts, &out, "GetAccountBalance", addr)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// GetAccountBalance is a free data retrieval call binding the contract method 0x28646213.
//
// Solidity: function GetAccountBalance(address addr) view returns(uint256)
func (_Lottery *LotterySession) GetAccountBalance(addr common.Address) (*big.Int, error) {
	return _Lottery.Contract.GetAccountBalance(&_Lottery.CallOpts, addr)
}

// GetAccountBalance is a free data retrieval call binding the contract method 0x28646213.
//
// Solidity: function GetAccountBalance(address addr) view returns(uint256)
func (_Lottery *LotteryCallerSession) GetAccountBalance(addr common.Address) (*big.Int, error) {
	return _Lottery.Contract.GetAccountBalance(&_Lottery.CallOpts, addr)
}

// Accounts is a free data retrieval call binding the contract method 0xf2a40db8.
//
// Solidity: function accounts(uint256 ) view returns(string addr, string nums)
func (_Lottery *LotteryCaller) Accounts(opts *bind.CallOpts, arg0 *big.Int) (struct {
	Addr string
	Nums string
}, error) {
	var out []interface{}
	err := _Lottery.contract.Call(opts, &out, "accounts", arg0)

	outstruct := new(struct {
		Addr string
		Nums string
	})
	if err != nil {
		return *outstruct, err
	}

	outstruct.Addr = *abi.ConvertType(out[0], new(string)).(*string)
	outstruct.Nums = *abi.ConvertType(out[1], new(string)).(*string)

	return *outstruct, err

}

// Accounts is a free data retrieval call binding the contract method 0xf2a40db8.
//
// Solidity: function accounts(uint256 ) view returns(string addr, string nums)
func (_Lottery *LotterySession) Accounts(arg0 *big.Int) (struct {
	Addr string
	Nums string
}, error) {
	return _Lottery.Contract.Accounts(&_Lottery.CallOpts, arg0)
}

// Accounts is a free data retrieval call binding the contract method 0xf2a40db8.
//
// Solidity: function accounts(uint256 ) view returns(string addr, string nums)
func (_Lottery *LotteryCallerSession) Accounts(arg0 *big.Int) (struct {
	Addr string
	Nums string
}, error) {
	return _Lottery.Contract.Accounts(&_Lottery.CallOpts, arg0)
}

// Acount is a free data retrieval call binding the contract method 0xecb109e9.
//
// Solidity: function acount() view returns(string addr, string nums)
func (_Lottery *LotteryCaller) Acount(opts *bind.CallOpts) (struct {
	Addr string
	Nums string
}, error) {
	var out []interface{}
	err := _Lottery.contract.Call(opts, &out, "acount")

	outstruct := new(struct {
		Addr string
		Nums string
	})
	if err != nil {
		return *outstruct, err
	}

	outstruct.Addr = *abi.ConvertType(out[0], new(string)).(*string)
	outstruct.Nums = *abi.ConvertType(out[1], new(string)).(*string)

	return *outstruct, err

}

// Acount is a free data retrieval call binding the contract method 0xecb109e9.
//
// Solidity: function acount() view returns(string addr, string nums)
func (_Lottery *LotterySession) Acount() (struct {
	Addr string
	Nums string
}, error) {
	return _Lottery.Contract.Acount(&_Lottery.CallOpts)
}

// Acount is a free data retrieval call binding the contract method 0xecb109e9.
//
// Solidity: function acount() view returns(string addr, string nums)
func (_Lottery *LotteryCallerSession) Acount() (struct {
	Addr string
	Nums string
}, error) {
	return _Lottery.Contract.Acount(&_Lottery.CallOpts)
}

// HistoryAccounts is a free data retrieval call binding the contract method 0x9d971738.
//
// Solidity: function history_accounts(uint8 , uint256 ) view returns(string addr, string nums)
func (_Lottery *LotteryCaller) HistoryAccounts(opts *bind.CallOpts, arg0 uint8, arg1 *big.Int) (struct {
	Addr string
	Nums string
}, error) {
	var out []interface{}
	err := _Lottery.contract.Call(opts, &out, "history_accounts", arg0, arg1)

	outstruct := new(struct {
		Addr string
		Nums string
	})
	if err != nil {
		return *outstruct, err
	}

	outstruct.Addr = *abi.ConvertType(out[0], new(string)).(*string)
	outstruct.Nums = *abi.ConvertType(out[1], new(string)).(*string)

	return *outstruct, err

}

// HistoryAccounts is a free data retrieval call binding the contract method 0x9d971738.
//
// Solidity: function history_accounts(uint8 , uint256 ) view returns(string addr, string nums)
func (_Lottery *LotterySession) HistoryAccounts(arg0 uint8, arg1 *big.Int) (struct {
	Addr string
	Nums string
}, error) {
	return _Lottery.Contract.HistoryAccounts(&_Lottery.CallOpts, arg0, arg1)
}

// HistoryAccounts is a free data retrieval call binding the contract method 0x9d971738.
//
// Solidity: function history_accounts(uint8 , uint256 ) view returns(string addr, string nums)
func (_Lottery *LotteryCallerSession) HistoryAccounts(arg0 uint8, arg1 *big.Int) (struct {
	Addr string
	Nums string
}, error) {
	return _Lottery.Contract.HistoryAccounts(&_Lottery.CallOpts, arg0, arg1)
}

// HistoryRetNums is a free data retrieval call binding the contract method 0xe8261b3c.
//
// Solidity: function history_ret_nums(uint8 , uint256 ) view returns(uint256)
func (_Lottery *LotteryCaller) HistoryRetNums(opts *bind.CallOpts, arg0 uint8, arg1 *big.Int) (*big.Int, error) {
	var out []interface{}
	err := _Lottery.contract.Call(opts, &out, "history_ret_nums", arg0, arg1)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// HistoryRetNums is a free data retrieval call binding the contract method 0xe8261b3c.
//
// Solidity: function history_ret_nums(uint8 , uint256 ) view returns(uint256)
func (_Lottery *LotterySession) HistoryRetNums(arg0 uint8, arg1 *big.Int) (*big.Int, error) {
	return _Lottery.Contract.HistoryRetNums(&_Lottery.CallOpts, arg0, arg1)
}

// HistoryRetNums is a free data retrieval call binding the contract method 0xe8261b3c.
//
// Solidity: function history_ret_nums(uint8 , uint256 ) view returns(uint256)
func (_Lottery *LotteryCallerSession) HistoryRetNums(arg0 uint8, arg1 *big.Int) (*big.Int, error) {
	return _Lottery.Contract.HistoryRetNums(&_Lottery.CallOpts, arg0, arg1)
}

// HistoryTotalMoney is a free data retrieval call binding the contract method 0x648531c4.
//
// Solidity: function history_total_money(uint8 ) view returns(uint256)
func (_Lottery *LotteryCaller) HistoryTotalMoney(opts *bind.CallOpts, arg0 uint8) (*big.Int, error) {
	var out []interface{}
	err := _Lottery.contract.Call(opts, &out, "history_total_money", arg0)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// HistoryTotalMoney is a free data retrieval call binding the contract method 0x648531c4.
//
// Solidity: function history_total_money(uint8 ) view returns(uint256)
func (_Lottery *LotterySession) HistoryTotalMoney(arg0 uint8) (*big.Int, error) {
	return _Lottery.Contract.HistoryTotalMoney(&_Lottery.CallOpts, arg0)
}

// HistoryTotalMoney is a free data retrieval call binding the contract method 0x648531c4.
//
// Solidity: function history_total_money(uint8 ) view returns(uint256)
func (_Lottery *LotteryCallerSession) HistoryTotalMoney(arg0 uint8) (*big.Int, error) {
	return _Lottery.Contract.HistoryTotalMoney(&_Lottery.CallOpts, arg0)
}

// Owner is a free data retrieval call binding the contract method 0x8da5cb5b.
//
// Solidity: function owner() view returns(address)
func (_Lottery *LotteryCaller) Owner(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _Lottery.contract.Call(opts, &out, "owner")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

// Owner is a free data retrieval call binding the contract method 0x8da5cb5b.
//
// Solidity: function owner() view returns(address)
func (_Lottery *LotterySession) Owner() (common.Address, error) {
	return _Lottery.Contract.Owner(&_Lottery.CallOpts)
}

// Owner is a free data retrieval call binding the contract method 0x8da5cb5b.
//
// Solidity: function owner() view returns(address)
func (_Lottery *LotteryCallerSession) Owner() (common.Address, error) {
	return _Lottery.Contract.Owner(&_Lottery.CallOpts)
}

// RetNums is a free data retrieval call binding the contract method 0x0d40a4a4.
//
// Solidity: function ret_nums(uint256 ) view returns(uint256)
func (_Lottery *LotteryCaller) RetNums(opts *bind.CallOpts, arg0 *big.Int) (*big.Int, error) {
	var out []interface{}
	err := _Lottery.contract.Call(opts, &out, "ret_nums", arg0)

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// RetNums is a free data retrieval call binding the contract method 0x0d40a4a4.
//
// Solidity: function ret_nums(uint256 ) view returns(uint256)
func (_Lottery *LotterySession) RetNums(arg0 *big.Int) (*big.Int, error) {
	return _Lottery.Contract.RetNums(&_Lottery.CallOpts, arg0)
}

// RetNums is a free data retrieval call binding the contract method 0x0d40a4a4.
//
// Solidity: function ret_nums(uint256 ) view returns(uint256)
func (_Lottery *LotteryCallerSession) RetNums(arg0 *big.Int) (*big.Int, error) {
	return _Lottery.Contract.RetNums(&_Lottery.CallOpts, arg0)
}

// Total is a free data retrieval call binding the contract method 0x2ddbd13a.
//
// Solidity: function total() view returns(uint8)
func (_Lottery *LotteryCaller) Total(opts *bind.CallOpts) (uint8, error) {
	var out []interface{}
	err := _Lottery.contract.Call(opts, &out, "total")

	if err != nil {
		return *new(uint8), err
	}

	out0 := *abi.ConvertType(out[0], new(uint8)).(*uint8)

	return out0, err

}

// Total is a free data retrieval call binding the contract method 0x2ddbd13a.
//
// Solidity: function total() view returns(uint8)
func (_Lottery *LotterySession) Total() (uint8, error) {
	return _Lottery.Contract.Total(&_Lottery.CallOpts)
}

// Total is a free data retrieval call binding the contract method 0x2ddbd13a.
//
// Solidity: function total() view returns(uint8)
func (_Lottery *LotteryCallerSession) Total() (uint8, error) {
	return _Lottery.Contract.Total(&_Lottery.CallOpts)
}

// Kaijiang is a paid mutator transaction binding the contract method 0x55e642ea.
//
// Solidity: function Kaijiang() returns()
func (_Lottery *LotteryTransactor) Kaijiang(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Lottery.contract.Transact(opts, "Kaijiang")
}

// Kaijiang is a paid mutator transaction binding the contract method 0x55e642ea.
//
// Solidity: function Kaijiang() returns()
func (_Lottery *LotterySession) Kaijiang() (*types.Transaction, error) {
	return _Lottery.Contract.Kaijiang(&_Lottery.TransactOpts)
}

// Kaijiang is a paid mutator transaction binding the contract method 0x55e642ea.
//
// Solidity: function Kaijiang() returns()
func (_Lottery *LotteryTransactorSession) Kaijiang() (*types.Transaction, error) {
	return _Lottery.Contract.Kaijiang(&_Lottery.TransactOpts)
}

// TouZhu is a paid mutator transaction binding the contract method 0x3b802712.
//
// Solidity: function TouZhu(string new_addr, string new_nums) payable returns()
func (_Lottery *LotteryTransactor) TouZhu(opts *bind.TransactOpts, new_addr string, new_nums string) (*types.Transaction, error) {
	return _Lottery.contract.Transact(opts, "TouZhu", new_addr, new_nums)
}

// TouZhu is a paid mutator transaction binding the contract method 0x3b802712.
//
// Solidity: function TouZhu(string new_addr, string new_nums) payable returns()
func (_Lottery *LotterySession) TouZhu(new_addr string, new_nums string) (*types.Transaction, error) {
	return _Lottery.Contract.TouZhu(&_Lottery.TransactOpts, new_addr, new_nums)
}

// TouZhu is a paid mutator transaction binding the contract method 0x3b802712.
//
// Solidity: function TouZhu(string new_addr, string new_nums) payable returns()
func (_Lottery *LotteryTransactorSession) TouZhu(new_addr string, new_nums string) (*types.Transaction, error) {
	return _Lottery.Contract.TouZhu(&_Lottery.TransactOpts, new_addr, new_nums)
}
