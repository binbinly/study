package main

import (
	_ "eth_block_project/routers"
	_ "eth_block_project/eth"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/toolbox"
	"eth_block_project/controllers"
)

func main() {

	controllers.InitTask()
	toolbox.StartTask()
	defer toolbox.StopTask()
	beego.Run()
}

