package main

import (
	"github.com/ethereum/go-ethereum/ethclient"
	"eth_block_project/eth"
	"github.com/ethereum/go-ethereum/common"
	"fmt"
)
func main() {


	client,err := ethclient.Dial("http://127.0.0.1:8545")
	if err != nil {
		panic("连接以太坊智能合约出错")
	}

	// 合约地址
	contract_addr := "0x92e25c8323D1d4b749EEe72EA1bCCAb0E0abf16F"
	common_contract_addr := common.HexToAddress(contract_addr)

	lottery ,err := eth.NewLottery(common_contract_addr,client)

	if err != nil {
		panic("实例化合约出错")
	}

	addr,err := lottery.Owner(nil)
	fmt.Println(addr)




}
