package main

import (
	"os"
	"fmt"
	"io/ioutil"
	"strings"
)

func GetFileName(dir string,user_name string) (filename string,exist bool) {
	files,err := ioutil.ReadDir(dir)



	if err != nil {
		return "",false
	}

	for _,f := range files {
		filename = f.Name()
		if strings.Contains(filename,user_name) {
			fmt.Println(filename)
			return filename,true
		}
	}

	return "",false


}
func main() {

	user_name := "ee7ec7e6b303601ff62e947664710c552c3f7943"
	dir := "eth/lottery_data/keystore/"
	filename,exist := GetFileName(dir,user_name)

	if exist {
		file_path := "eth/lottery_data/keystore/"+filename

		file,_ := os.Open(file_path)

		file_info,_ := file.Stat()
		file_size := file_info.Size()

		buffer := make([]byte,file_size)

		file.Read(buffer)
		fmt.Println(string(buffer))
	}else {
		fmt.Println("用户名输入有误")
	}


}

