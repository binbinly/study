package main

import (
	"strings"
	"fmt"
)

func main() {

	nums := "2 1 3 3 3"

	new_nums := strings.Split(nums," ")
	fmt.Println(new_nums)
}



