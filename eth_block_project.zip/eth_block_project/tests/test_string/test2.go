package main

import "time"

func main() {
	var a time.Duration

	b := a.Seconds()


}
