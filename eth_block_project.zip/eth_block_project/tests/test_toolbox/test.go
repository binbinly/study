package main

import (
	"github.com/astaxie/beego/toolbox"
	"fmt"
)
func main() {

	task := toolbox.NewTask("mytask","3 * * * * *",test)
	//task.Run()
	//  进程守护方式运行
	toolbox.AddTask("mytask",task)
	toolbox.StartTask()


}

func test() error  {

	fmt.Println("=====hello toolbox")
	return nil

}