package utils

import (
	"io/ioutil"
	"strings"
)

func GetFileName(dir string,user_name string) (filename string,exist bool) {

	files,err := ioutil.ReadDir(dir)


	if err != nil {
		return "",false
	}

	for _,f := range files {
		filename = f.Name()
		if strings.Contains(filename,user_name) {
			return filename,true
		}
	}

	return "",false


}
