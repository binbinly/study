package main

import (
	//_"github.com/ethereum/go-ethereum/crypto"

	"github.com/ethereum/go-ethereum/ethclient"
	"github.com/ethereum/go-ethereum/common"
	"eth_block_test/utils/contract/TestAddress"
	"fmt"
)

func main() {

	// 连接rpc
	client,err := ethclient.Dial("http://127.0.0.1:8545")

	if err != nil {
		panic("连接以太坊合约出错")
	}

	// 定义要操作合约的账户地址
	addr := "0x29794ab2ed6c47faff7ebdd6dcdd71a263e25460"
	// 将字符串地址转为common.Address
	common_addr := common.HexToAddress(addr)



	// 创建合约对象
	contract_obj,err11 := contract.NewTestAddress(common_addr,client)
	if err11 !=nil {
		panic("创建合约对象出错")
	}

	fmt.Println(contract_obj.TestAddressCaller) // Caller访问函数
	fmt.Println(contract_obj.TestAddressTransactor) // Transactor 有函数
	fmt.Println(contract_obj.TestAddressFilterer)  // 没什么作用


}
