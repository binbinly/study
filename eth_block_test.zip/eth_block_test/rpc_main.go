package main

import (
	_ "eth_block_test/utils"
	"fmt"
	"eth_block_test/utils/personal"
	//"eth_block_test/utils/db"
)

func main() {

	//fmt.Println("===================net")
	//// 获取networkdid
	//networkid,err := net.GetNetWorkId()
	//fmt.Println(err)
	//fmt.Println(networkid)
	//
	//// 获取is_listenging
	//is_listening,err2 := net.GetNetIsListening()
	//fmt.Println(is_listening)
	//fmt.Println(err2)
	//
	//// 获取对端节点数量
	//count,err3 := net.GetNetPeerCount()
	//fmt.Println(err3)
	//fmt.Println(count)
	//
	//
	//fmt.Println("===================eth")
	//// 获取账户地址列表
	//accounts,err4 := eth.GetAccountList()
	//fmt.Println(err4)
	//fmt.Println(accounts)
	//
	//// 获取指定账户余额
	//balance,err5 := eth.GetAccountBalance("0x518438fb3fce69cb8405dcff0e4cf9ccb3f160e4")
	//fmt.Println(err5)
	//fmt.Println(balance)
	//
	//// 获取gas的价格
	//gas_price,err6 := eth.GetGasPrice()
	//fmt.Println(err6)
	//fmt.Println(gas_price)
	//
	//// 获取挖矿账户地址
	//coin_base,err7 := eth.GetCoinBase()
	//fmt.Println(err7)
	//fmt.Println(coin_base)
	//
	//// 获取以太坊的协议版本
	//protocolVersion,err8 := eth.GetProtoColVersion()
	//fmt.Println(err8)
	//fmt.Println(protocolVersion)
	//
	//is_mining,err9 :=  eth.GetIsMining()
	//fmt.Println(err9)
	//fmt.Println(is_mining)
	//
	//hashrate,err10 := eth.GetHashRate()
	//fmt.Println(err10)
	//fmt.Println(hashrate)
	//
	//tr_count,err11 := eth.GetTransactionCount("0xf8cd3ed8b46f6b277f7cf458704dbc99aedda699")
	//fmt.Println(err11)
	//fmt.Println(tr_count)
	//
	//blockNum,err12  := eth.GetBlockNumber()
	//fmt.Println(err12)
	//fmt.Println(blockNum)
	//
	//
	//fmt.Println("===================personal")
	//
	//// 账户地址列表
	//accounts2,err13 := personal.GetAccountList()
	//fmt.Println(err13)
	//fmt.Println(accounts2)
	//// 创建账户
	account,err14 := personal.NewAccount("12345678")
	fmt.Println(err14)
	fmt.Println(account)
	//
	//// 锁定账户
	////is_lock ,err15 := personal.LockAccount("0xf8cd3ed8b46f6b277f7cf458704dbc99aedda699")
	////fmt.Println(err15)
	////fmt.Println(is_lock)
	//
	//// 解锁账户
	//is_unlock ,err16 := personal.UnLockAccount("0x518438fb3fce69cb8405dcff0e4cf9ccb3f160e4","12345678")
	//fmt.Println(err16)
	//fmt.Println(is_unlock)


	//fmt.Println("=====================db")
	//is_ok,err17 :=  db.PushString("000014.ldb","name","hallen")
	//fmt.Println(err17)
	//fmt.Println(is_ok)

}
