package main

import (
	"github.com/ethereum/go-ethereum/ethclient"
	"github.com/ethereum/go-ethereum/common"
	"eth_block_test/utils/contract/test1"
	"fmt"
)


func main() {

	// 连接rpc
	client,err := ethclient.Dial("http://127.0.0.1:8545")

	if err != nil {
		panic("连接以太坊合约出错")
	}

	// 定义要操作合约的合约地址
	addr := "0x482B990b27dEE623f8D51eF2CB1eb8bDA40626CD"
	// 0x482B990b27dEE623f8D51eF2CB1eb8bDA40626CD
	// 将字符串地址转为common.Address
	common_contract_addr := common.HexToAddress(addr)



	// 创建合约对象
	contract_obj,err11 := test1.NewTest1(common_contract_addr,client)
	if err11 !=nil {
		panic("创建合约对象出错")
	}

	fmt.Println(contract_obj.Name(nil))



}
