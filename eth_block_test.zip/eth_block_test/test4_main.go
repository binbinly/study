package main

import (
	"github.com/ethereum/go-ethereum/ethclient"
	"github.com/ethereum/go-ethereum/common"
	"eth_block_test/utils/contract/test4"
	"fmt"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"io/ioutil"
	"strings"
	"math/big"
)



func main() {

	// 连接rpc
	client,err := ethclient.Dial("http://127.0.0.1:8545")

	if err != nil {
		panic("连接以太坊合约出错")
	}

	// 定义要操作合约的合约地址
	addr := "0xdEDd24C11Fc7E63eA8f78D704213eE415C8B635D"
	// 将字符串地址转为common.Address
	common_contract_addr := common.HexToAddress(addr)

	// 读取账户json文件
	var keystore_path string = "hallen2/keystore/UTC--2021-03-05T03-57-22.772053000Z--29794ab2ed6c47faff7ebdd6dcdd71a263e25460"
	var pwd string = "12345678"

	byte_data,err_file := ioutil.ReadFile(keystore_path)

	if err_file != nil {
		fmt.Println(err_file)
		panic("读取key出错")
	}

	// 创建合约对象
	contract_obj,err11 := test4.NewTest4(common_contract_addr,client)
	if err11 !=nil {
		panic("创建合约对象出错")
	}


	// 初始化交易信息
	auth,err_auth := bind.NewTransactorWithChainID(strings.NewReader(string(byte_data)),pwd,big.NewInt(15))

	if err_auth != nil {
		panic("初始化交易出错")
	}

	auth.GasLimit = uint64(3000000)
	auth.GasPrice = big.NewInt(20)
	auth.Value = big.NewInt(100)
	fmt.Println(auth.From)
	// 设置name
	tx,err2 := contract_obj.ContractGetMoney(auth)
	fmt.Println(err2)
	fmt.Println(tx)

	// 获取状态变量的name值
	tx2 ,err3 := contract_obj.GetContractBalance(auth)
	fmt.Println(err3)
	fmt.Println(tx2)

	balance,err4 := contract_obj.Balance(nil)
	fmt.Println(err4)
	fmt.Println(balance)


}
