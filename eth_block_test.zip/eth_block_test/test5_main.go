package main

import (
	"github.com/ethereum/go-ethereum/ethclient"
	"github.com/ethereum/go-ethereum/common"
	"eth_block_test/utils/contract/test5"
	"fmt"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"io/ioutil"
	"strings"
	"math/big"
)



func main() {

	// 连接rpc
	client,err := ethclient.Dial("http://127.0.0.1:8545")

	if err != nil {
		panic("连接以太坊合约出错")
	}

	// 定义要操作合约的合约地址
	addr := "0x0C9D586A81D22E06DB2625a0F8590fA27ae99382"
	// 将字符串地址转为common.Address
	common_contract_addr := common.HexToAddress(addr)

	// 读取账户json文件
	var keystore_path string = "hallen2/keystore/UTC--2021-03-05T03-57-22.772053000Z--29794ab2ed6c47faff7ebdd6dcdd71a263e25460"
	var pwd string = "12345678"

	byte_data,err_file := ioutil.ReadFile(keystore_path)

	if err_file != nil {
		fmt.Println(err_file)
		panic("读取key出错")
	}

	// 创建合约对象
	contract_obj,err11 := test5.NewTest5(common_contract_addr,client)

	if err11 !=nil {
		panic("创建合约对象出错")
	}


	// 初始化交易信息
	auth,err_auth := bind.NewTransactorWithChainID(strings.NewReader(string(byte_data)),pwd,big.NewInt(15))

	if err_auth != nil {
		panic("初始化交易出错")
	}

	auth.GasLimit = uint64(3000000)
	auth.GasPrice = big.NewInt(2000)

	auth.Value = big.NewInt(1000)


	// 设置转账
	contract_obj.ContractGetMonet(auth)


	// 获取合约余额到状态变量balance
	contract_obj.GetContractBalance(auth)

	// 获取balance的值
	balance,err4 := contract_obj.Balance(nil)
	fmt.Println(err4)
	fmt.Println(balance)

	// 传收钱的账户
	contract_obj.GetAccount(auth,common.HexToAddress("0xaafd79b33cf5c444349e11935aac545a7121dcfc"))


	// 获取账户
	account,err55 := contract_obj.Addr(nil)
	fmt.Println(err55)
	fmt.Println(account)


	// 转账 ,从合约--》指定账户
	//auth.From = common_contract_addr
	auth.Value = big.NewInt(5)
	_,err66 := contract_obj.TransferToAccount(auth)
	fmt.Println(err66)



}
