// Code generated - DO NOT EDIT.
// This file is a generated binding and any manual changes will be lost.

package test2

import (
	"math/big"
	"strings"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/event"
)

// Reference imports to suppress errors if they are not otherwise used.
var (
	_ = big.NewInt
	_ = strings.NewReader
	_ = ethereum.NotFound
	_ = bind.Bind
	_ = common.Big1
	_ = types.BloomLookup
	_ = event.NewSubscription
)

// Test2ABI is the input ABI used to generate the binding from.
const Test2ABI = "[{\"constant\":true,\"inputs\":[{\"name\":\"name\",\"type\":\"string\"}],\"name\":\"get_name\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"}]"

// Test2 is an auto generated Go binding around an Ethereum contract.
type Test2 struct {
	Test2Caller     // Read-only binding to the contract
	Test2Transactor // Write-only binding to the contract
	Test2Filterer   // Log filterer for contract events
}

// Test2Caller is an auto generated read-only Go binding around an Ethereum contract.
type Test2Caller struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Test2Transactor is an auto generated write-only Go binding around an Ethereum contract.
type Test2Transactor struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Test2Filterer is an auto generated log filtering Go binding around an Ethereum contract events.
type Test2Filterer struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Test2Session is an auto generated Go binding around an Ethereum contract,
// with pre-set call and transact options.
type Test2Session struct {
	Contract     *Test2            // Generic contract binding to set the session for
	CallOpts     bind.CallOpts     // Call options to use throughout this session
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// Test2CallerSession is an auto generated read-only Go binding around an Ethereum contract,
// with pre-set call options.
type Test2CallerSession struct {
	Contract *Test2Caller  // Generic contract caller binding to set the session for
	CallOpts bind.CallOpts // Call options to use throughout this session
}

// Test2TransactorSession is an auto generated write-only Go binding around an Ethereum contract,
// with pre-set transact options.
type Test2TransactorSession struct {
	Contract     *Test2Transactor  // Generic contract transactor binding to set the session for
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// Test2Raw is an auto generated low-level Go binding around an Ethereum contract.
type Test2Raw struct {
	Contract *Test2 // Generic contract binding to access the raw methods on
}

// Test2CallerRaw is an auto generated low-level read-only Go binding around an Ethereum contract.
type Test2CallerRaw struct {
	Contract *Test2Caller // Generic read-only contract binding to access the raw methods on
}

// Test2TransactorRaw is an auto generated low-level write-only Go binding around an Ethereum contract.
type Test2TransactorRaw struct {
	Contract *Test2Transactor // Generic write-only contract binding to access the raw methods on
}

// NewTest2 creates a new instance of Test2, bound to a specific deployed contract.
func NewTest2(address common.Address, backend bind.ContractBackend) (*Test2, error) {
	contract, err := bindTest2(address, backend, backend, backend)
	if err != nil {
		return nil, err
	}
	return &Test2{Test2Caller: Test2Caller{contract: contract}, Test2Transactor: Test2Transactor{contract: contract}, Test2Filterer: Test2Filterer{contract: contract}}, nil
}

// NewTest2Caller creates a new read-only instance of Test2, bound to a specific deployed contract.
func NewTest2Caller(address common.Address, caller bind.ContractCaller) (*Test2Caller, error) {
	contract, err := bindTest2(address, caller, nil, nil)
	if err != nil {
		return nil, err
	}
	return &Test2Caller{contract: contract}, nil
}

// NewTest2Transactor creates a new write-only instance of Test2, bound to a specific deployed contract.
func NewTest2Transactor(address common.Address, transactor bind.ContractTransactor) (*Test2Transactor, error) {
	contract, err := bindTest2(address, nil, transactor, nil)
	if err != nil {
		return nil, err
	}
	return &Test2Transactor{contract: contract}, nil
}

// NewTest2Filterer creates a new log filterer instance of Test2, bound to a specific deployed contract.
func NewTest2Filterer(address common.Address, filterer bind.ContractFilterer) (*Test2Filterer, error) {
	contract, err := bindTest2(address, nil, nil, filterer)
	if err != nil {
		return nil, err
	}
	return &Test2Filterer{contract: contract}, nil
}

// bindTest2 binds a generic wrapper to an already deployed contract.
func bindTest2(address common.Address, caller bind.ContractCaller, transactor bind.ContractTransactor, filterer bind.ContractFilterer) (*bind.BoundContract, error) {
	parsed, err := abi.JSON(strings.NewReader(Test2ABI))
	if err != nil {
		return nil, err
	}
	return bind.NewBoundContract(address, parsed, caller, transactor, filterer), nil
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Test2 *Test2Raw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Test2.Contract.Test2Caller.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Test2 *Test2Raw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Test2.Contract.Test2Transactor.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Test2 *Test2Raw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Test2.Contract.Test2Transactor.contract.Transact(opts, method, params...)
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Test2 *Test2CallerRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Test2.Contract.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Test2 *Test2TransactorRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Test2.Contract.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Test2 *Test2TransactorRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Test2.Contract.contract.Transact(opts, method, params...)
}

// GetName is a free data retrieval call binding the contract method 0xa8f5d7a6.
//
// Solidity: function get_name(string name) view returns(string)
func (_Test2 *Test2Caller) GetName(opts *bind.CallOpts, name string) (string, error) {
	var out []interface{}
	err := _Test2.contract.Call(opts, &out, "get_name", name)

	if err != nil {
		return *new(string), err
	}

	out0 := *abi.ConvertType(out[0], new(string)).(*string)

	return out0, err

}

// GetName is a free data retrieval call binding the contract method 0xa8f5d7a6.
//
// Solidity: function get_name(string name) view returns(string)
func (_Test2 *Test2Session) GetName(name string) (string, error) {
	return _Test2.Contract.GetName(&_Test2.CallOpts, name)
}

// GetName is a free data retrieval call binding the contract method 0xa8f5d7a6.
//
// Solidity: function get_name(string name) view returns(string)
func (_Test2 *Test2CallerSession) GetName(name string) (string, error) {
	return _Test2.Contract.GetName(&_Test2.CallOpts, name)
}
