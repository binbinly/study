// Code generated - DO NOT EDIT.
// This file is a generated binding and any manual changes will be lost.

package test3

import (
	"math/big"
	"strings"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/event"
)

// Reference imports to suppress errors if they are not otherwise used.
var (
	_ = big.NewInt
	_ = strings.NewReader
	_ = ethereum.NotFound
	_ = bind.Bind
	_ = common.Big1
	_ = types.BloomLookup
	_ = event.NewSubscription
)

// Test3ABI is the input ABI used to generate the binding from.
const Test3ABI = "[{\"constant\":false,\"inputs\":[{\"name\":\"str\",\"type\":\"string\"}],\"name\":\"set_name\",\"outputs\":[],\"payable\":true,\"stateMutability\":\"payable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"name\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"}]"

// Test3 is an auto generated Go binding around an Ethereum contract.
type Test3 struct {
	Test3Caller     // Read-only binding to the contract
	Test3Transactor // Write-only binding to the contract
	Test3Filterer   // Log filterer for contract events
}

// Test3Caller is an auto generated read-only Go binding around an Ethereum contract.
type Test3Caller struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Test3Transactor is an auto generated write-only Go binding around an Ethereum contract.
type Test3Transactor struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Test3Filterer is an auto generated log filtering Go binding around an Ethereum contract events.
type Test3Filterer struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Test3Session is an auto generated Go binding around an Ethereum contract,
// with pre-set call and transact options.
type Test3Session struct {
	Contract     *Test3            // Generic contract binding to set the session for
	CallOpts     bind.CallOpts     // Call options to use throughout this session
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// Test3CallerSession is an auto generated read-only Go binding around an Ethereum contract,
// with pre-set call options.
type Test3CallerSession struct {
	Contract *Test3Caller  // Generic contract caller binding to set the session for
	CallOpts bind.CallOpts // Call options to use throughout this session
}

// Test3TransactorSession is an auto generated write-only Go binding around an Ethereum contract,
// with pre-set transact options.
type Test3TransactorSession struct {
	Contract     *Test3Transactor  // Generic contract transactor binding to set the session for
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// Test3Raw is an auto generated low-level Go binding around an Ethereum contract.
type Test3Raw struct {
	Contract *Test3 // Generic contract binding to access the raw methods on
}

// Test3CallerRaw is an auto generated low-level read-only Go binding around an Ethereum contract.
type Test3CallerRaw struct {
	Contract *Test3Caller // Generic read-only contract binding to access the raw methods on
}

// Test3TransactorRaw is an auto generated low-level write-only Go binding around an Ethereum contract.
type Test3TransactorRaw struct {
	Contract *Test3Transactor // Generic write-only contract binding to access the raw methods on
}

// NewTest3 creates a new instance of Test3, bound to a specific deployed contract.
func NewTest3(address common.Address, backend bind.ContractBackend) (*Test3, error) {
	contract, err := bindTest3(address, backend, backend, backend)
	if err != nil {
		return nil, err
	}
	return &Test3{Test3Caller: Test3Caller{contract: contract}, Test3Transactor: Test3Transactor{contract: contract}, Test3Filterer: Test3Filterer{contract: contract}}, nil
}

// NewTest3Caller creates a new read-only instance of Test3, bound to a specific deployed contract.
func NewTest3Caller(address common.Address, caller bind.ContractCaller) (*Test3Caller, error) {
	contract, err := bindTest3(address, caller, nil, nil)
	if err != nil {
		return nil, err
	}
	return &Test3Caller{contract: contract}, nil
}

// NewTest3Transactor creates a new write-only instance of Test3, bound to a specific deployed contract.
func NewTest3Transactor(address common.Address, transactor bind.ContractTransactor) (*Test3Transactor, error) {
	contract, err := bindTest3(address, nil, transactor, nil)
	if err != nil {
		return nil, err
	}
	return &Test3Transactor{contract: contract}, nil
}

// NewTest3Filterer creates a new log filterer instance of Test3, bound to a specific deployed contract.
func NewTest3Filterer(address common.Address, filterer bind.ContractFilterer) (*Test3Filterer, error) {
	contract, err := bindTest3(address, nil, nil, filterer)
	if err != nil {
		return nil, err
	}
	return &Test3Filterer{contract: contract}, nil
}

// bindTest3 binds a generic wrapper to an already deployed contract.
func bindTest3(address common.Address, caller bind.ContractCaller, transactor bind.ContractTransactor, filterer bind.ContractFilterer) (*bind.BoundContract, error) {
	parsed, err := abi.JSON(strings.NewReader(Test3ABI))
	if err != nil {
		return nil, err
	}
	return bind.NewBoundContract(address, parsed, caller, transactor, filterer), nil
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Test3 *Test3Raw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Test3.Contract.Test3Caller.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Test3 *Test3Raw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Test3.Contract.Test3Transactor.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Test3 *Test3Raw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Test3.Contract.Test3Transactor.contract.Transact(opts, method, params...)
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Test3 *Test3CallerRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Test3.Contract.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Test3 *Test3TransactorRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Test3.Contract.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Test3 *Test3TransactorRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Test3.Contract.contract.Transact(opts, method, params...)
}

// Name is a free data retrieval call binding the contract method 0x06fdde03.
//
// Solidity: function name() view returns(string)
func (_Test3 *Test3Caller) Name(opts *bind.CallOpts) (string, error) {
	var out []interface{}
	err := _Test3.contract.Call(opts, &out, "name")

	if err != nil {
		return *new(string), err
	}

	out0 := *abi.ConvertType(out[0], new(string)).(*string)

	return out0, err

}

// Name is a free data retrieval call binding the contract method 0x06fdde03.
//
// Solidity: function name() view returns(string)
func (_Test3 *Test3Session) Name() (string, error) {
	return _Test3.Contract.Name(&_Test3.CallOpts)
}

// Name is a free data retrieval call binding the contract method 0x06fdde03.
//
// Solidity: function name() view returns(string)
func (_Test3 *Test3CallerSession) Name() (string, error) {
	return _Test3.Contract.Name(&_Test3.CallOpts)
}

// SetName is a paid mutator transaction binding the contract method 0x6b701e08.
//
// Solidity: function set_name(string str) payable returns()
func (_Test3 *Test3Transactor) SetName(opts *bind.TransactOpts, str string) (*types.Transaction, error) {
	return _Test3.contract.Transact(opts, "set_name", str)
}

// SetName is a paid mutator transaction binding the contract method 0x6b701e08.
//
// Solidity: function set_name(string str) payable returns()
func (_Test3 *Test3Session) SetName(str string) (*types.Transaction, error) {
	return _Test3.Contract.SetName(&_Test3.TransactOpts, str)
}

// SetName is a paid mutator transaction binding the contract method 0x6b701e08.
//
// Solidity: function set_name(string str) payable returns()
func (_Test3 *Test3TransactorSession) SetName(str string) (*types.Transaction, error) {
	return _Test3.Contract.SetName(&_Test3.TransactOpts, str)
}
