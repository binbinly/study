// Code generated - DO NOT EDIT.
// This file is a generated binding and any manual changes will be lost.

package test4

import (
	"math/big"
	"strings"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/event"
)

// Reference imports to suppress errors if they are not otherwise used.
var (
	_ = big.NewInt
	_ = strings.NewReader
	_ = ethereum.NotFound
	_ = bind.Bind
	_ = common.Big1
	_ = types.BloomLookup
	_ = event.NewSubscription
)

// Test4ABI is the input ABI used to generate the binding from.
const Test4ABI = "[{\"constant\":true,\"inputs\":[],\"name\":\"balance\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[],\"name\":\"contract_get_money\",\"outputs\":[],\"payable\":true,\"stateMutability\":\"payable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[],\"name\":\"get_contract_balance\",\"outputs\":[],\"payable\":true,\"stateMutability\":\"payable\",\"type\":\"function\"}]"

// Test4 is an auto generated Go binding around an Ethereum contract.
type Test4 struct {
	Test4Caller     // Read-only binding to the contract
	Test4Transactor // Write-only binding to the contract
	Test4Filterer   // Log filterer for contract events
}

// Test4Caller is an auto generated read-only Go binding around an Ethereum contract.
type Test4Caller struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Test4Transactor is an auto generated write-only Go binding around an Ethereum contract.
type Test4Transactor struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Test4Filterer is an auto generated log filtering Go binding around an Ethereum contract events.
type Test4Filterer struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Test4Session is an auto generated Go binding around an Ethereum contract,
// with pre-set call and transact options.
type Test4Session struct {
	Contract     *Test4            // Generic contract binding to set the session for
	CallOpts     bind.CallOpts     // Call options to use throughout this session
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// Test4CallerSession is an auto generated read-only Go binding around an Ethereum contract,
// with pre-set call options.
type Test4CallerSession struct {
	Contract *Test4Caller  // Generic contract caller binding to set the session for
	CallOpts bind.CallOpts // Call options to use throughout this session
}

// Test4TransactorSession is an auto generated write-only Go binding around an Ethereum contract,
// with pre-set transact options.
type Test4TransactorSession struct {
	Contract     *Test4Transactor  // Generic contract transactor binding to set the session for
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// Test4Raw is an auto generated low-level Go binding around an Ethereum contract.
type Test4Raw struct {
	Contract *Test4 // Generic contract binding to access the raw methods on
}

// Test4CallerRaw is an auto generated low-level read-only Go binding around an Ethereum contract.
type Test4CallerRaw struct {
	Contract *Test4Caller // Generic read-only contract binding to access the raw methods on
}

// Test4TransactorRaw is an auto generated low-level write-only Go binding around an Ethereum contract.
type Test4TransactorRaw struct {
	Contract *Test4Transactor // Generic write-only contract binding to access the raw methods on
}

// NewTest4 creates a new instance of Test4, bound to a specific deployed contract.
func NewTest4(address common.Address, backend bind.ContractBackend) (*Test4, error) {
	contract, err := bindTest4(address, backend, backend, backend)
	if err != nil {
		return nil, err
	}
	return &Test4{Test4Caller: Test4Caller{contract: contract}, Test4Transactor: Test4Transactor{contract: contract}, Test4Filterer: Test4Filterer{contract: contract}}, nil
}

// NewTest4Caller creates a new read-only instance of Test4, bound to a specific deployed contract.
func NewTest4Caller(address common.Address, caller bind.ContractCaller) (*Test4Caller, error) {
	contract, err := bindTest4(address, caller, nil, nil)
	if err != nil {
		return nil, err
	}
	return &Test4Caller{contract: contract}, nil
}

// NewTest4Transactor creates a new write-only instance of Test4, bound to a specific deployed contract.
func NewTest4Transactor(address common.Address, transactor bind.ContractTransactor) (*Test4Transactor, error) {
	contract, err := bindTest4(address, nil, transactor, nil)
	if err != nil {
		return nil, err
	}
	return &Test4Transactor{contract: contract}, nil
}

// NewTest4Filterer creates a new log filterer instance of Test4, bound to a specific deployed contract.
func NewTest4Filterer(address common.Address, filterer bind.ContractFilterer) (*Test4Filterer, error) {
	contract, err := bindTest4(address, nil, nil, filterer)
	if err != nil {
		return nil, err
	}
	return &Test4Filterer{contract: contract}, nil
}

// bindTest4 binds a generic wrapper to an already deployed contract.
func bindTest4(address common.Address, caller bind.ContractCaller, transactor bind.ContractTransactor, filterer bind.ContractFilterer) (*bind.BoundContract, error) {
	parsed, err := abi.JSON(strings.NewReader(Test4ABI))
	if err != nil {
		return nil, err
	}
	return bind.NewBoundContract(address, parsed, caller, transactor, filterer), nil
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Test4 *Test4Raw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Test4.Contract.Test4Caller.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Test4 *Test4Raw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Test4.Contract.Test4Transactor.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Test4 *Test4Raw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Test4.Contract.Test4Transactor.contract.Transact(opts, method, params...)
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Test4 *Test4CallerRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Test4.Contract.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Test4 *Test4TransactorRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Test4.Contract.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Test4 *Test4TransactorRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Test4.Contract.contract.Transact(opts, method, params...)
}

// Balance is a free data retrieval call binding the contract method 0xb69ef8a8.
//
// Solidity: function balance() view returns(uint256)
func (_Test4 *Test4Caller) Balance(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _Test4.contract.Call(opts, &out, "balance")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// Balance is a free data retrieval call binding the contract method 0xb69ef8a8.
//
// Solidity: function balance() view returns(uint256)
func (_Test4 *Test4Session) Balance() (*big.Int, error) {
	return _Test4.Contract.Balance(&_Test4.CallOpts)
}

// Balance is a free data retrieval call binding the contract method 0xb69ef8a8.
//
// Solidity: function balance() view returns(uint256)
func (_Test4 *Test4CallerSession) Balance() (*big.Int, error) {
	return _Test4.Contract.Balance(&_Test4.CallOpts)
}

// ContractGetMoney is a paid mutator transaction binding the contract method 0xc2590145.
//
// Solidity: function contract_get_money() payable returns()
func (_Test4 *Test4Transactor) ContractGetMoney(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Test4.contract.Transact(opts, "contract_get_money")
}

// ContractGetMoney is a paid mutator transaction binding the contract method 0xc2590145.
//
// Solidity: function contract_get_money() payable returns()
func (_Test4 *Test4Session) ContractGetMoney() (*types.Transaction, error) {
	return _Test4.Contract.ContractGetMoney(&_Test4.TransactOpts)
}

// ContractGetMoney is a paid mutator transaction binding the contract method 0xc2590145.
//
// Solidity: function contract_get_money() payable returns()
func (_Test4 *Test4TransactorSession) ContractGetMoney() (*types.Transaction, error) {
	return _Test4.Contract.ContractGetMoney(&_Test4.TransactOpts)
}

// GetContractBalance is a paid mutator transaction binding the contract method 0xf0bc153a.
//
// Solidity: function get_contract_balance() payable returns()
func (_Test4 *Test4Transactor) GetContractBalance(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Test4.contract.Transact(opts, "get_contract_balance")
}

// GetContractBalance is a paid mutator transaction binding the contract method 0xf0bc153a.
//
// Solidity: function get_contract_balance() payable returns()
func (_Test4 *Test4Session) GetContractBalance() (*types.Transaction, error) {
	return _Test4.Contract.GetContractBalance(&_Test4.TransactOpts)
}

// GetContractBalance is a paid mutator transaction binding the contract method 0xf0bc153a.
//
// Solidity: function get_contract_balance() payable returns()
func (_Test4 *Test4TransactorSession) GetContractBalance() (*types.Transaction, error) {
	return _Test4.Contract.GetContractBalance(&_Test4.TransactOpts)
}
