// Code generated - DO NOT EDIT.
// This file is a generated binding and any manual changes will be lost.

package test5

import (
	"math/big"
	"strings"

	ethereum "github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/event"
)

// Reference imports to suppress errors if they are not otherwise used.
var (
	_ = big.NewInt
	_ = strings.NewReader
	_ = ethereum.NotFound
	_ = bind.Bind
	_ = common.Big1
	_ = types.BloomLookup
	_ = event.NewSubscription
)

// Test5ABI is the input ABI used to generate the binding from.
const Test5ABI = "[{\"constant\":false,\"inputs\":[],\"name\":\"contract_get_monet\",\"outputs\":[],\"payable\":true,\"stateMutability\":\"payable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"account\",\"type\":\"address\"}],\"name\":\"get_account\",\"outputs\":[],\"payable\":true,\"stateMutability\":\"payable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"addr\",\"outputs\":[{\"name\":\"\",\"type\":\"address\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"balance\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[],\"name\":\"transfer_to_account\",\"outputs\":[],\"payable\":true,\"stateMutability\":\"payable\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[],\"name\":\"get_contract_balance\",\"outputs\":[],\"payable\":true,\"stateMutability\":\"payable\",\"type\":\"function\"}]"

// Test5 is an auto generated Go binding around an Ethereum contract.
type Test5 struct {
	Test5Caller     // Read-only binding to the contract
	Test5Transactor // Write-only binding to the contract
	Test5Filterer   // Log filterer for contract events
}

// Test5Caller is an auto generated read-only Go binding around an Ethereum contract.
type Test5Caller struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Test5Transactor is an auto generated write-only Go binding around an Ethereum contract.
type Test5Transactor struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Test5Filterer is an auto generated log filtering Go binding around an Ethereum contract events.
type Test5Filterer struct {
	contract *bind.BoundContract // Generic contract wrapper for the low level calls
}

// Test5Session is an auto generated Go binding around an Ethereum contract,
// with pre-set call and transact options.
type Test5Session struct {
	Contract     *Test5            // Generic contract binding to set the session for
	CallOpts     bind.CallOpts     // Call options to use throughout this session
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// Test5CallerSession is an auto generated read-only Go binding around an Ethereum contract,
// with pre-set call options.
type Test5CallerSession struct {
	Contract *Test5Caller  // Generic contract caller binding to set the session for
	CallOpts bind.CallOpts // Call options to use throughout this session
}

// Test5TransactorSession is an auto generated write-only Go binding around an Ethereum contract,
// with pre-set transact options.
type Test5TransactorSession struct {
	Contract     *Test5Transactor  // Generic contract transactor binding to set the session for
	TransactOpts bind.TransactOpts // Transaction auth options to use throughout this session
}

// Test5Raw is an auto generated low-level Go binding around an Ethereum contract.
type Test5Raw struct {
	Contract *Test5 // Generic contract binding to access the raw methods on
}

// Test5CallerRaw is an auto generated low-level read-only Go binding around an Ethereum contract.
type Test5CallerRaw struct {
	Contract *Test5Caller // Generic read-only contract binding to access the raw methods on
}

// Test5TransactorRaw is an auto generated low-level write-only Go binding around an Ethereum contract.
type Test5TransactorRaw struct {
	Contract *Test5Transactor // Generic write-only contract binding to access the raw methods on
}

// NewTest5 creates a new instance of Test5, bound to a specific deployed contract.
func NewTest5(address common.Address, backend bind.ContractBackend) (*Test5, error) {
	contract, err := bindTest5(address, backend, backend, backend)
	if err != nil {
		return nil, err
	}
	return &Test5{Test5Caller: Test5Caller{contract: contract}, Test5Transactor: Test5Transactor{contract: contract}, Test5Filterer: Test5Filterer{contract: contract}}, nil
}

// NewTest5Caller creates a new read-only instance of Test5, bound to a specific deployed contract.
func NewTest5Caller(address common.Address, caller bind.ContractCaller) (*Test5Caller, error) {
	contract, err := bindTest5(address, caller, nil, nil)
	if err != nil {
		return nil, err
	}
	return &Test5Caller{contract: contract}, nil
}

// NewTest5Transactor creates a new write-only instance of Test5, bound to a specific deployed contract.
func NewTest5Transactor(address common.Address, transactor bind.ContractTransactor) (*Test5Transactor, error) {
	contract, err := bindTest5(address, nil, transactor, nil)
	if err != nil {
		return nil, err
	}
	return &Test5Transactor{contract: contract}, nil
}

// NewTest5Filterer creates a new log filterer instance of Test5, bound to a specific deployed contract.
func NewTest5Filterer(address common.Address, filterer bind.ContractFilterer) (*Test5Filterer, error) {
	contract, err := bindTest5(address, nil, nil, filterer)
	if err != nil {
		return nil, err
	}
	return &Test5Filterer{contract: contract}, nil
}

// bindTest5 binds a generic wrapper to an already deployed contract.
func bindTest5(address common.Address, caller bind.ContractCaller, transactor bind.ContractTransactor, filterer bind.ContractFilterer) (*bind.BoundContract, error) {
	parsed, err := abi.JSON(strings.NewReader(Test5ABI))
	if err != nil {
		return nil, err
	}
	return bind.NewBoundContract(address, parsed, caller, transactor, filterer), nil
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Test5 *Test5Raw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Test5.Contract.Test5Caller.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Test5 *Test5Raw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Test5.Contract.Test5Transactor.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Test5 *Test5Raw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Test5.Contract.Test5Transactor.contract.Transact(opts, method, params...)
}

// Call invokes the (constant) contract method with params as input values and
// sets the output to result. The result type might be a single field for simple
// returns, a slice of interfaces for anonymous returns and a struct for named
// returns.
func (_Test5 *Test5CallerRaw) Call(opts *bind.CallOpts, result *[]interface{}, method string, params ...interface{}) error {
	return _Test5.Contract.contract.Call(opts, result, method, params...)
}

// Transfer initiates a plain transaction to move funds to the contract, calling
// its default method if one is available.
func (_Test5 *Test5TransactorRaw) Transfer(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Test5.Contract.contract.Transfer(opts)
}

// Transact invokes the (paid) contract method with params as input values.
func (_Test5 *Test5TransactorRaw) Transact(opts *bind.TransactOpts, method string, params ...interface{}) (*types.Transaction, error) {
	return _Test5.Contract.contract.Transact(opts, method, params...)
}

// Addr is a free data retrieval call binding the contract method 0x767800de.
//
// Solidity: function addr() view returns(address)
func (_Test5 *Test5Caller) Addr(opts *bind.CallOpts) (common.Address, error) {
	var out []interface{}
	err := _Test5.contract.Call(opts, &out, "addr")

	if err != nil {
		return *new(common.Address), err
	}

	out0 := *abi.ConvertType(out[0], new(common.Address)).(*common.Address)

	return out0, err

}

// Addr is a free data retrieval call binding the contract method 0x767800de.
//
// Solidity: function addr() view returns(address)
func (_Test5 *Test5Session) Addr() (common.Address, error) {
	return _Test5.Contract.Addr(&_Test5.CallOpts)
}

// Addr is a free data retrieval call binding the contract method 0x767800de.
//
// Solidity: function addr() view returns(address)
func (_Test5 *Test5CallerSession) Addr() (common.Address, error) {
	return _Test5.Contract.Addr(&_Test5.CallOpts)
}

// Balance is a free data retrieval call binding the contract method 0xb69ef8a8.
//
// Solidity: function balance() view returns(uint256)
func (_Test5 *Test5Caller) Balance(opts *bind.CallOpts) (*big.Int, error) {
	var out []interface{}
	err := _Test5.contract.Call(opts, &out, "balance")

	if err != nil {
		return *new(*big.Int), err
	}

	out0 := *abi.ConvertType(out[0], new(*big.Int)).(**big.Int)

	return out0, err

}

// Balance is a free data retrieval call binding the contract method 0xb69ef8a8.
//
// Solidity: function balance() view returns(uint256)
func (_Test5 *Test5Session) Balance() (*big.Int, error) {
	return _Test5.Contract.Balance(&_Test5.CallOpts)
}

// Balance is a free data retrieval call binding the contract method 0xb69ef8a8.
//
// Solidity: function balance() view returns(uint256)
func (_Test5 *Test5CallerSession) Balance() (*big.Int, error) {
	return _Test5.Contract.Balance(&_Test5.CallOpts)
}

// ContractGetMonet is a paid mutator transaction binding the contract method 0x1d70b8de.
//
// Solidity: function contract_get_monet() payable returns()
func (_Test5 *Test5Transactor) ContractGetMonet(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Test5.contract.Transact(opts, "contract_get_monet")
}

// ContractGetMonet is a paid mutator transaction binding the contract method 0x1d70b8de.
//
// Solidity: function contract_get_monet() payable returns()
func (_Test5 *Test5Session) ContractGetMonet() (*types.Transaction, error) {
	return _Test5.Contract.ContractGetMonet(&_Test5.TransactOpts)
}

// ContractGetMonet is a paid mutator transaction binding the contract method 0x1d70b8de.
//
// Solidity: function contract_get_monet() payable returns()
func (_Test5 *Test5TransactorSession) ContractGetMonet() (*types.Transaction, error) {
	return _Test5.Contract.ContractGetMonet(&_Test5.TransactOpts)
}

// GetAccount is a paid mutator transaction binding the contract method 0x3c559fd3.
//
// Solidity: function get_account(address account) payable returns()
func (_Test5 *Test5Transactor) GetAccount(opts *bind.TransactOpts, account common.Address) (*types.Transaction, error) {
	return _Test5.contract.Transact(opts, "get_account", account)
}

// GetAccount is a paid mutator transaction binding the contract method 0x3c559fd3.
//
// Solidity: function get_account(address account) payable returns()
func (_Test5 *Test5Session) GetAccount(account common.Address) (*types.Transaction, error) {
	return _Test5.Contract.GetAccount(&_Test5.TransactOpts, account)
}

// GetAccount is a paid mutator transaction binding the contract method 0x3c559fd3.
//
// Solidity: function get_account(address account) payable returns()
func (_Test5 *Test5TransactorSession) GetAccount(account common.Address) (*types.Transaction, error) {
	return _Test5.Contract.GetAccount(&_Test5.TransactOpts, account)
}

// GetContractBalance is a paid mutator transaction binding the contract method 0xf0bc153a.
//
// Solidity: function get_contract_balance() payable returns()
func (_Test5 *Test5Transactor) GetContractBalance(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Test5.contract.Transact(opts, "get_contract_balance")
}

// GetContractBalance is a paid mutator transaction binding the contract method 0xf0bc153a.
//
// Solidity: function get_contract_balance() payable returns()
func (_Test5 *Test5Session) GetContractBalance() (*types.Transaction, error) {
	return _Test5.Contract.GetContractBalance(&_Test5.TransactOpts)
}

// GetContractBalance is a paid mutator transaction binding the contract method 0xf0bc153a.
//
// Solidity: function get_contract_balance() payable returns()
func (_Test5 *Test5TransactorSession) GetContractBalance() (*types.Transaction, error) {
	return _Test5.Contract.GetContractBalance(&_Test5.TransactOpts)
}

// TransferToAccount is a paid mutator transaction binding the contract method 0xc206c61e.
//
// Solidity: function transfer_to_account() payable returns()
func (_Test5 *Test5Transactor) TransferToAccount(opts *bind.TransactOpts) (*types.Transaction, error) {
	return _Test5.contract.Transact(opts, "transfer_to_account")
}

// TransferToAccount is a paid mutator transaction binding the contract method 0xc206c61e.
//
// Solidity: function transfer_to_account() payable returns()
func (_Test5 *Test5Session) TransferToAccount() (*types.Transaction, error) {
	return _Test5.Contract.TransferToAccount(&_Test5.TransactOpts)
}

// TransferToAccount is a paid mutator transaction binding the contract method 0xc206c61e.
//
// Solidity: function transfer_to_account() payable returns()
func (_Test5 *Test5TransactorSession) TransferToAccount() (*types.Transaction, error) {
	return _Test5.Contract.TransferToAccount(&_Test5.TransactOpts)
}
