package db

import "eth_block_test/utils"

func PushString(db_name,key_name,value string) (is_ok string,err error)  {

	err = utils.Client.Call(&is_ok,"db_getString",db_name,key_name,value)

	if err != nil {
		return is_ok,err
	}

	return is_ok,nil
	
}
