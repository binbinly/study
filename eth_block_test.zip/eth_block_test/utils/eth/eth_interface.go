package eth

import "eth_block_test/utils"

// 获取账户地址列表
func GetAccountList() (accounts []string,err error)  {

	err = utils.Client.Call(&accounts,"eth_accounts")
	if err != nil {
		return accounts,err
	}

	return accounts,nil
	
}

// 获取指定账户余额
func GetAccountBalance(account string) (balance string,err error){

	err = utils.Client.Call(&balance,"eth_getBalance",account,"latest")

	if err != nil {
		return balance,err
	}

	return balance,nil


}

// 获取gas的价格
func GetGasPrice() (gas_price string,err error) {
	err = utils.Client.Call(&gas_price,"eth_gasPrice")

	if err != nil {
		return gas_price,err
	}

	return gas_price,nil
	
}

// 获取挖矿账户地址
func GetCoinBase() (coinbase string,err error) {
	err = utils.Client.Call(&coinbase,"eth_coinbase")

	if err != nil {
		return coinbase,err
	}

	return coinbase,nil

}

// 获取以太坊的协议版本
func GetProtoColVersion() (protocolVersion string,err error)  {
	err = utils.Client.Call(&protocolVersion,"eth_protocolVersion")

	if err != nil {
		return protocolVersion,err
	}
	return protocolVersion,nil

}

// 是否在挖矿中
func GetIsMining() (is_mining bool,err error) {
	err = utils.Client.Call(&is_mining,"eth_mining")
	if err != nil {
		return is_mining,err
	}
	return is_mining,nil
	
}

// 获取每秒计算的哈希数量
func GetHashRate() (hashrate string,err error) {
	err = utils.Client.Call(&hashrate,"eth_hashrate")
	if err != nil {
		return hashrate,err
	}
	return hashrate,nil
	
}

// 返回指定地址的交易数量
func GetTransactionCount(addr string) (count string,err error)  {

	err = utils.Client.Call(&count,"eth_getTransactionCount",addr,"latest")
	if err != nil {
		return count,err
	}
	return count,nil

}


// 获取当前节点的块号
func GetBlockNumber() (blockNum string,err error) {
	err = utils.Client.Call(&blockNum,"eth_blockNumber")

	if err != nil {
		return blockNum,err
	}
	return blockNum,nil
	
}