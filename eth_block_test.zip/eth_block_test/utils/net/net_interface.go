package net

import (
	"eth_block_test/utils"
)

func GetNetWorkId() (networkid string,err error)  {
	err = utils.Client.Call(&networkid,"net_version")
	if err != nil {
		return networkid,err
	}
	return networkid,nil
	
}

func GetNetIsListening()(is_listening bool,err error)  {
	err = utils.Client.Call(&is_listening,"net_listening")

	if err != nil {
		return is_listening,err
	}

	return is_listening,nil
	
}

func GetNetPeerCount() (count string,err error) {

	err = utils.Client.Call(&count,"net_peerCount")
	if err != nil {
		return count,err
	}

	return count,nil

}
