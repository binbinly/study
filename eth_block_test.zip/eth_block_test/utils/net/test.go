package net

import (
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"math/big"
	"context"
	"github.com/ethereum/go-ethereum/core/types"
)

func main() {


	// 认证信息组装
	auth := bind.NewKeyedTransactor(fromPrivkey)
	auth.From = common_addr


	// gasLimit
	var gasLimit uint64 = 300000

	// gasPrice
	var gasPrice *big.Int = big.NewInt(200)

	// 交易额
	amount := big.NewInt(100)

	// nonce获取
	nonce, err55 := client.PendingNonceAt(context.Background(), common_addr)
	fmt.Println(nonce)
	fmt.Println(err55)
	// 交易创建
	toAddr := common.HexToAddress("0xb0fa3fadb9c42e46015dd28f3741d5ec86d10ff497cdd53b162d921bd230cc45")
	tx := types.NewTransaction(nonce,toAddr,amount,gasLimit,gasPrice,[]byte{})

	signedTx ,err:= auth.Signer(auth.From, tx)

	bind.SignerFn(common_addr,tx)

	opt := bind.TransactOpts{
		From:common_addr,  // 从哪个账户转钱
		Signer:signedTx,
		Value:amount,  // 要转的钱
		Nonce:big.NewInt(int64(nonce)),
		GasLimit:gasLimit,
		GasPrice:gasPrice,

	}
	tra,err22 := contract_obj.GetMoney(&opt)
	fmt.Println(err22)
	fmt.Println(tra)
}
