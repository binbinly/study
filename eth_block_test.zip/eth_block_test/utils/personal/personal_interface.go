package personal

import "eth_block_test/utils"


// 获取该节点下的所有账户地址
func GetAccountList() (accounts []string,err error) {

	err = utils.Client.Call(&accounts,"personal_listAccounts")
	if err != nil {
		return accounts,err
	}

	return accounts,nil

}

// 创建一个用户
func NewAccount(pwd string) (account string,err error)  {
	err = utils.Client.Call(&account,"personal_newAccount",pwd)

	if err != nil {
		return account,err
	}
	return account,nil
	
}

// 锁定用户
func LockAccount(addr string) (is_lock bool,err error)  {
	err = utils.Client.Call(&is_lock,"personal_lockAccount",addr)

	if err != nil {
		return is_lock,err
	}
	return is_lock,nil

}

// 解锁账户
func UnLockAccount(addr,pwd string) (is_unlock bool,err error)  {
	err = utils.Client.Call(&is_unlock,"personal_unlockAccount",addr,pwd)

	if err != nil {
		return is_unlock,err
	}
	return is_unlock,nil

}