package authority

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"encoding/json"
	"fabric-zhiliao-project/application/sdk/authority"
)

func Query(ctx *gin.Context)  {

	bh := ctx.Query("bh")

	chaincode_name := "authorityCc"
	fcn := "query"
	args := [][]byte{[]byte(bh)}

	rsp,err := authority_sdk.ChannelQuery(chaincode_name,fcn,args)



	if err != nil {
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusBadRequest,
			"msg":"查询失败",
			"data":nil,
		})
		return
	}

	map_data := make(map[string]interface{})

	json.Unmarshal([]byte(string(rsp.Payload)),&map_data)

	map_data["bh"] = bh

	ctx.JSON(http.StatusOK,gin.H{
		"code":http.StatusOK,
		"msg":"查询成功",
		"data":map_data,
	})
	return


}

func Set(ctx *gin.Context)  {

	// 房屋编号
	bh := ctx.PostForm("bh")
	// 房屋所有人
	syr := ctx.PostForm("syr")
	// 房屋地址
	dz := ctx.PostForm("dz")
	// 房屋类型
	lx := ctx.PostForm("lx")

	chaincode_name := "authorityCc"
	fcn := "set"
	args := [][]byte{[]byte(bh),[]byte(syr),[]byte(dz),[]byte(lx)}


	_,err := authority_sdk.ChannelExecute(chaincode_name,fcn,args)

	if error.Error(err) == "Client Status Code: (5) TIMEOUT. Description: request timed out or been cancelled"{
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusOK,
			"msg":"添加成功",
		})
	}else if error.Error(err) == "Transaction processing for endorser [localhost:9051]: gRPC Transport Status Code: (2) Unknown. Description: chaincode error (status: 500, message: 该房屋编号已存在)"{
		ctx.JSON(http.StatusBadRequest,gin.H{
			"code":http.StatusBadRequest,
			"msg":"房屋编号已存在",
		})
	}else {
		ctx.JSON(http.StatusBadRequest,gin.H{
			"code":http.StatusBadRequest,
			"msg":"添加失败",
		})
	}



}


