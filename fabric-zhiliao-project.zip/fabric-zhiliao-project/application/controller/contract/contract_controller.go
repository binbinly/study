package contract


import (
	"github.com/gin-gonic/gin"
	"net/http"
	"fabric-zhiliao-project/application/sdk/credit"
	"encoding/json"
	"crypto/sha256"
	"encoding/hex"
	"io"
)

func Query(ctx *gin.Context)  {

	htbh := ctx.Query("htbh")

	chaincode_name := "contractCc"
	fcn := "query"
	args := [][]byte{[]byte(htbh)}

	rsp,err := credit_sdk.ChannelQuery(chaincode_name,fcn,args)



	if err != nil {
		ctx.JSON(http.StatusBadRequest,gin.H{
			"code":http.StatusBadRequest,
			"msg":"查询失败",

		})
	}

	map_data := make(map[string]interface{})

	json.Unmarshal([]byte(string(rsp.Payload)),&map_data)

	map_data["htbh"] = htbh


	ctx.JSON(http.StatusOK,gin.H{
		"code":http.StatusOK,
		"msg":"查询成功",
		"data":map_data,
	})


}

func Set(ctx *gin.Context)  {

	// 合同编号
	htbh := ctx.PostForm("htbh")
	// 租户身份证号
	id_card := ctx.PostForm("id_card")
	// 房屋id
	fwbh := ctx.PostForm("fwbh")

	// 1.获取合同图片,key：contract_pic
	fileheader,err := ctx.FormFile("contract_pic")

	// todo 合同编号不同，合同图片也就不同
	//同一个图片，不能用在不同的合同编号上
	// 1.链码：加个query_hash
	// 2.sdk
	// 3.上链的时候需要做hash验证

	if err != nil {
		ctx.JSON(http.StatusBadRequest,gin.H{
			"code":http.StatusBadRequest,
			"msg":"上传图片失败",
		})
	}

	// 2.将图片的hash值拿到,返回：ht_hash
	sha256_hash := sha256.New()

	file,err := fileheader.Open()

	if err != nil {
		ctx.JSON(http.StatusBadRequest,gin.H{
			"code":http.StatusBadRequest,
			"msg":"上传图片失败",
		})
	}

	_,err = io.Copy(sha256_hash,file)
	if err != nil {
		ctx.JSON(http.StatusBadRequest,gin.H{
			"code":http.StatusBadRequest,
			"msg":"上传图片失败",
		})
	}
	sum_byte := sha256_hash.Sum(nil)
	ht_hash := hex.EncodeToString([]byte(sum_byte))


	chaincode_name := "contractCc"
	fcn := "set"
	args := [][]byte{[]byte(htbh),[]byte(id_card),[]byte(fwbh),[]byte(ht_hash)}


	_,err = credit_sdk.ChannelExecute(chaincode_name,fcn,args)


	if error.Error(err) == "Client Status Code: (5) TIMEOUT. Description: request timed out or been cancelled"{
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusOK,
			"msg":"添加成功",
		})
	}else if error.Error(err) == "Transaction processing for endorser [localhost:11051]: gRPC Transport Status Code: (2) Unknown. Description: chaincode error (status: 500, message: 该合同编号已存在)"{
		ctx.JSON(http.StatusBadRequest,gin.H{
			"code":http.StatusBadRequest,
			"msg":"合同编号已存在",
		})
	}else {
		ctx.JSON(http.StatusBadRequest,gin.H{
			"code":http.StatusBadRequest,
			"msg":"添加失败",
		})
	}



}

