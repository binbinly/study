package credit

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"fabric-zhiliao-project/application/sdk/credit"

)

func Query(ctx *gin.Context)  {

	id_card := ctx.Query("id_card")

	chaincode_name := "creditCc"
	fcn := "query"
	args := [][]byte{[]byte(id_card)}

	rsp,err := credit_sdk.ChannelQuery(chaincode_name,fcn,args)



	if err != nil {
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusBadRequest,
			"msg":"查询失败",

		})
		return
	}

	map_data := map[string]interface{}{
		"step":string(rsp.Payload),
		"id_card":id_card,
	}

	ctx.JSON(http.StatusOK,gin.H{
		"code":http.StatusOK,
		"msg":"查询成功",
		"data":map_data,
	})
	return


}

func Set(ctx *gin.Context)  {

	// 身份证号
	id_card := ctx.PostForm("id_card")
	// 信用級別
	step := ctx.PostForm("step")


	chaincode_name := "creditCc"
	fcn := "set"
	args := [][]byte{[]byte(id_card),[]byte(step)}


	_,err := credit_sdk.ChannelExecute(chaincode_name,fcn,args)

	if error.Error(err) == "Client Status Code: (5) TIMEOUT. Description: request timed out or been cancelled"{
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusOK,
			"msg":"添加成功",
		})
	}else if error.Error(err) == "Transaction processing for endorser [localhost:11051]: gRPC Transport Status Code: (2) Unknown. Description: chaincode error (status: 500, message: 该房屋编号已存在)"{
		ctx.JSON(http.StatusBadRequest,gin.H{
			"code":http.StatusBadRequest,
			"msg":"房屋编号已存在",
		})
	}else {
		ctx.JSON(http.StatusBadRequest,gin.H{
			"code":http.StatusBadRequest,
			"msg":"添加失败",
		})
	}



}



