package police

import (
	"github.com/gin-gonic/gin"
	"fabric-zhiliao-project/application/sdk/police"
	"net/http"
	"encoding/json"
)

func Query(ctx *gin.Context)  {

	id_card := ctx.Query("id_card")

	chaincode_name := "policeCc"
	fcn := "query"
	args := [][]byte{[]byte(id_card)}

	rsp,err := police_sdk.ChannelQuery(chaincode_name,fcn,args)



	if err != nil || string(rsp.Payload) == ""{
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusBadRequest,
			"msg":"查询失败",
			"data":nil,
		})
		return
	}


	map_data := make(map[string]interface{})

	json.Unmarshal([]byte(string(rsp.Payload)),&map_data)

	map_data["id_card"] = id_card

	ctx.JSON(http.StatusOK,gin.H{
		"code":http.StatusOK,
		"msg":"查询成功",
		"data":map_data,
	})
	return


}

func Set(ctx *gin.Context)  {

	id_card := ctx.PostForm("id_card")
	name := ctx.PostForm("name")
	age := ctx.PostForm("age")
	addr := ctx.PostForm("addr")

	chaincode_name := "policeCc"
	fcn := "set"
	args := [][]byte{[]byte(id_card),[]byte(name),[]byte(age),[]byte(addr)}


	_,err := police_sdk.ChannelExecute(chaincode_name,fcn,args)

	if error.Error(err) == "Client Status Code: (5) TIMEOUT. Description: request timed out or been cancelled"{
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusOK,
			"msg":"添加成功",
		})
		return
	}else if error.Error(err) == "Transaction processing for endorser [localhost:7051]: gRPC Transport Status Code: (2) Unknown. Description: chaincode error (status: 500, message: 该身份证号已存在)"{
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusBadRequest,
			"msg":"身份证号已存在",
		})
		return
	}else {
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusBadRequest,
			"msg":"添加失败",
			"data":nil,
		})
		return
	}



}
