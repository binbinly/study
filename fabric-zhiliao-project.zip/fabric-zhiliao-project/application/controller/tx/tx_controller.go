package tx


import (
	"github.com/gin-gonic/gin"
	"net/http"
	"encoding/json"
	"fabric-zhiliao-project/application/sdk/credit"
	"fmt"
)

func Query(ctx *gin.Context)  {

	orderId := ctx.Query("orderId")
	qs := ctx.Query("qs")

	key := fmt.Sprintf("%s-%s",orderId,qs)
	chaincode_name := "txCc"
	fcn := "query"
	args := [][]byte{[]byte(key)}

	rsp,err := credit_sdk.ChannelQuery(chaincode_name,fcn,args)



	if err != nil {
		ctx.JSON(http.StatusBadRequest,gin.H{
			"code":http.StatusBadRequest,
			"msg":"查询失败",
			"data":nil,
		})
	}


	map_data := make(map[string]interface{})

	err = json.Unmarshal([]byte(string(rsp.Payload)),&map_data)

	map_data["orderId"] = orderId

	ctx.JSON(http.StatusOK,gin.H{
		"code":http.StatusOK,
		"msg":"查询成功",
		"data":map_data,
	})


}

func Set(ctx *gin.Context)  {

	// 订单编号
	orderId := ctx.PostForm("orderId")
	// 分期期数
	qs := ctx.PostForm("qs")
	// 订单编号-期数
	orderId_qs := fmt.Sprintf("%s-%s",orderId,qs)
	// 房东姓名
	fd_name := ctx.PostForm("fd_name")
	// 房东身份证号
	fd_idcard := ctx.PostForm("fd_idcard")
	// 租户姓名
	zh_name := ctx.PostForm("zh_name")
	// 租户身份证号
	zh_idcard := ctx.PostForm("zh_idcard")
	// 房屋编号
	fwbh := ctx.PostForm("fwbh")
	// 租金
	zj := ctx.PostForm("zj")
	// 交易时间
	jysj := ctx.PostForm("jysj")
	// 合同编号
	htbh := ctx.PostForm("htbh")
	// 备注
	desc := ctx.PostForm("desc")



	chaincode_name := "txCc"
	fcn := "set"
	args := [][]byte{
		[]byte(orderId_qs),
		[]byte(orderId),
		[]byte(qs),
		[]byte(fd_name),
		[]byte(fd_idcard),
		[]byte(zh_name),
		[]byte(zh_idcard),
		[]byte(fwbh),
		[]byte(zj),
		[]byte(jysj),
		[]byte(htbh),
		[]byte(desc),
		}


	_,err := credit_sdk.ChannelExecute(chaincode_name,fcn,args)

	if error.Error(err) == "Client Status Code: (5) TIMEOUT. Description: request timed out or been cancelled"{
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusOK,
			"msg":"添加成功",
		})
	}else if error.Error(err) == "Transaction processing for endorser [localhost:11051]: gRPC Transport Status Code: (2) Unknown. Description: chaincode error (status: 500, message: 该订单编号-期数已存在)"{
		ctx.JSON(http.StatusBadRequest,gin.H{
			"code":http.StatusBadRequest,
			"msg":"订单编号-期数已存在",
		})
	}else {
		ctx.JSON(http.StatusBadRequest,gin.H{
			"code":http.StatusBadRequest,
			"msg":"添加失败",
			"data":nil,
		})
	}



}

