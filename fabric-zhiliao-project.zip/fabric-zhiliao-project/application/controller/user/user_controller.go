package user


import (
	"github.com/gin-gonic/gin"
	"net/http"
	"encoding/json"
	"fabric-zhiliao-project/application/sdk/credit"
	"fmt"
	"fabric-zhiliao-project/application/sdk/police"
)

func Login(ctx *gin.Context)  {

	username := ctx.PostForm("username")
	pwd := ctx.PostForm("pwd")
	role := ctx.PostForm("role")


	k := fmt.Sprintf("%s-%s-%s",username,pwd,role)

	chaincode_name := "userCc"
	fcn := "query"
	args := [][]byte{[]byte(k)}

	rsp,err := credit_sdk.ChannelQuery(chaincode_name,fcn,args)



	if err != nil || string(rsp.Payload) == ""{
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusBadRequest,
			"msg":"登录失败",
			"data":nil,
		})
		return
	}


	map_data := make(map[string]interface{})

	err = json.Unmarshal([]byte(string(rsp.Payload)),&map_data)

	ctx.JSON(http.StatusOK,gin.H{
		"code":http.StatusOK,
		"msg":"登录成功",
		"data":map_data,
	})
	return


}

func Set(ctx *gin.Context)  {

	id_card := ctx.PostForm("id_card")
	username := ctx.PostForm("username")
	pwd := ctx.PostForm("pwd")
	role := ctx.PostForm("role")
	age := ctx.PostForm("age")
	gender := ctx.PostForm("gender")

	if role == "4" {
		// 个人认证
		chaincode_name_police := "policeCc"
		fcn_police := "query"
		args_police := [][]byte{
			[]byte(id_card),
		}
		rsp,_ := police_sdk.ChannelQuery(chaincode_name_police,fcn_police,args_police)

		if string(rsp.Payload) == "" {
			ctx.JSON(http.StatusOK,gin.H{
				"code":http.StatusBadRequest,
				"msg":"公安系统没有该身份证号，先去注册!",
			})
			return
		}
	}


	chaincode_name := "userCc"
	fcn := "set"
	args := [][]byte{
		[]byte(role),
		[]byte(username),
		[]byte(pwd),
		[]byte(age),
		[]byte(gender),
	}


	_,err := credit_sdk.ChannelExecute(chaincode_name,fcn,args)

	if error.Error(err) == "Client Status Code: (5) TIMEOUT. Description: request timed out or been cancelled"{
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusOK,
			"msg":"注册成功",
		})
		return

	}else if error.Error(err) == "Transaction processing for endorser [localhost:11051]: gRPC Transport Status Code: (2) Unknown. Description: chaincode error (status: 500, message: 该用户已存在)"{
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusBadRequest,
			"msg":"用户已存在",
		})
		return
	}else {
		ctx.JSON(http.StatusOK,gin.H{
			"code":http.StatusBadRequest,
			"msg":"注册失败",
			"data":nil,
		})
		return
	}



}


