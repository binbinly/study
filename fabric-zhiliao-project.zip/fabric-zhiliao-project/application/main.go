package main

import (
	"github.com/gin-gonic/gin"
	"fabric-zhiliao-project/application/router"
	"fabric-zhiliao-project/application/middle_ware"
)
/*
gin框架运行的主入口
 */

func main() {

	router := gin.Default()


	router.Use(middle_ware.CorsMiddleWare)

	all_router.InitRouter(router)


	router.Run()

}
