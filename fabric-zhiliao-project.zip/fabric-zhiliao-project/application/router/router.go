package all_router

import (
	"github.com/gin-gonic/gin"
	"fabric-zhiliao-project/application/controller/police"
	"fabric-zhiliao-project/application/controller/authority"
	"fabric-zhiliao-project/application/controller/credit"
	"fabric-zhiliao-project/application/controller/contract"
	"fabric-zhiliao-project/application/controller/tx"
	"fabric-zhiliao-project/application/controller/user"
)

func InitRouter(router *gin.Engine)  {

	police_group := router.Group("/police")
	authority_group := router.Group("/authority")
	credit_group := router.Group("/credit")
	contract_group := router.Group("/contract")
	tx_group := router.Group("/tx")
	user_group := router.Group("/user")

	police.Router(police_group)

	authority.Router(authority_group)

	credit.Router(credit_group)

	contract.Router(contract_group)

	tx.Router(tx_group)

	user.Router(user_group)


}
