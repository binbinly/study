package main

import (
	pb "github.com/hyperledger/fabric/protos/peer"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"fmt"
)
type AuthorityCc struct {}

/*
	"房屋编号":"{"房屋所有人","房屋地址","房屋类型"}
 */
func (p *AuthorityCc)Init(stub shim.ChaincodeStubInterface) pb.Response {
	_,args := stub.GetFunctionAndParameters()

	if len(args) != 4 {
		return shim.Error("参数长度必须为4(房屋编号,房屋所有人,房屋地址,房屋类型)")
	}
	// 房屋编号
	bh := args[0]
	// 房屋所有人
	syr := args[1]
	// 房屋地址
	dz := args[2]
	// 房屋类型
	lx := args[3]

	value := fmt.Sprintf(`{"syr":"%s","dz":"%s","lx":"%s"}`,syr,dz,lx)
	err := stub.PutState(bh,[]byte(value))

	if err != nil {
		return shim.Error("写入账本失败")
	}

	return shim.Success([]byte("初始化成功"))
}

// 新增
func (p *AuthorityCc)setValue(stub shim.ChaincodeStubInterface,args []string) pb.Response   {

	if len(args) != 4 {
		return shim.Error("参数长度必须为4(房屋编号,房屋所有人,房屋地址,房屋类型)")
	}
	// 房屋编号
	bh := args[0]
	// 房屋所有人
	syr := args[1]
	// 房屋地址
	dz := args[2]
	// 房屋类型
	lx := args[3]

	// 如果账本中没有该房屋编号则新增，否则返回错误
	rsp,err := stub.GetState(bh)

	// 注意：key不存在也不会报错，但是返回的空的
	if string(rsp) != "" {  // 表示存在
		return shim.Error("该房屋编号已存在")
	}

	value := fmt.Sprintf(`{"syr":"%s","dz":"%s","lx":"%s"}`,syr,dz,lx)
	err = stub.PutState(bh,[]byte(value))

	if err != nil {
		return shim.Error("新增失败")
	}

	return shim.Success([]byte("新增成功"))

}

// 查询
func (p *AuthorityCc)query(stub shim.ChaincodeStubInterface,args []string) pb.Response  {

	if len(args) != 1 {
		return shim.Error("参数必须为房屋编号，参数个数为1")
	}

	bh := args[0]


	bh_byte,err := stub.GetState(bh)

	if err != nil {
		return shim.Error("没有该房屋编号")
	}

	return shim.Success(bh_byte)
}


func (p *AuthorityCc)Invoke(stub shim.ChaincodeStubInterface) pb.Response  {

	f,args := stub.GetFunctionAndParameters()

	if f == "set" {
		return p.setValue(stub,args)
	}

	if f == "query" {
		return p.query(stub,args)
	}

	return shim.Error("函数名称错误，只能是set或query")
}


func main() {
	err := shim.Start(new(AuthorityCc))

	if err != nil {
		fmt.Println("启动fabric发生错误")
	}
}
