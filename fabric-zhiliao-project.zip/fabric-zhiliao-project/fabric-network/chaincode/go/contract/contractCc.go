package main

import (
	pb "github.com/hyperledger/fabric/protos/peer"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"fmt"
)
type ContractCc struct {}

/*
	合同管理：
		key：合同编号
		value：租户身份证号以及房屋id，合同图片hash
 */
func (p *ContractCc)Init(stub shim.ChaincodeStubInterface) pb.Response {
	_,args := stub.GetFunctionAndParameters()

	if len(args) != 4 {
		return shim.Error("参数长度必须为4(合同编号,租户身份证号,房屋id,合同图片hash值")
	}
	// 合同编号
	htbh := args[0]
	// 租户身份证号
	id_card := args[1]
	// 房屋id
	fwbh := args[2]
	// 合同图片hash
	ht_hash := args[3]


	value := fmt.Sprintf(`{"id_card":"%s","fwbh":"%s","ht_hash":"%s"}`,id_card,fwbh,ht_hash)
	err := stub.PutState(htbh,[]byte(value))

	if err != nil {
		return shim.Error("写入账本失败")
	}

	return shim.Success([]byte("初始化成功"))
}

// 新增
func (p *ContractCc)setValue(stub shim.ChaincodeStubInterface,args []string) pb.Response   {

	if len(args) != 4 {
		return shim.Error("参数长度必须为4(合同编号,租户身份证号,房屋id,合同图片hash值")
	}
	// 合同编号
	htbh := args[0]
	// 租户身份证号
	id_card := args[1]
	// 房屋id
	fwbh := args[2]
	// 合同图片hash
	ht_hash := args[3]




	// 如果账本中没有该合同编号则新增，否则返回错误
	rsp,err := stub.GetState(htbh)

	// 注意：key不存在也不会报错，但是返回的空的
	if string(rsp) != "" {  // 表示存在
		return shim.Error("该合同编号已存在")
	}

	value := fmt.Sprintf(`{"id_card":"%s","fwbh":"%s","ht_hash":"%s"}`,id_card,fwbh,ht_hash)
	err = stub.PutState(htbh,[]byte(value))

	if err != nil {
		return shim.Error("新增失败")
	}

	return shim.Success([]byte("新增成功"))

}

// 查询：合同编号
func (p *ContractCc)query(stub shim.ChaincodeStubInterface,args []string) pb.Response  {

	if len(args) != 1 {
		return shim.Error("参数必须为合同编号，参数个数为1")
	}

	bh := args[0]


	bh_byte,err := stub.GetState(bh)

	if err != nil {
		return shim.Error("没有该合同编号")
	}

	return shim.Success(bh_byte)
}


func (p *ContractCc)Invoke(stub shim.ChaincodeStubInterface) pb.Response  {

	f,args := stub.GetFunctionAndParameters()

	if f == "set" {
		return p.setValue(stub,args)
	}

	if f == "query" {
		return p.query(stub,args)
	}

	return shim.Error("函数名称错误，只能是set或query")
}


func main() {
	err := shim.Start(new(ContractCc))

	if err != nil {
		fmt.Println("启动fabric发生错误")
	}
}
