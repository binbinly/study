package main

import (
	pb "github.com/hyperledger/fabric/protos/peer"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"fmt"
)
type CreditCc struct {}

/*
	"身份证号":信用級別
		A級別：信用最好
		B級別：信用及格
		C級別：信用差
 */
func (p *CreditCc)Init(stub shim.ChaincodeStubInterface) pb.Response {
	_,args := stub.GetFunctionAndParameters()

	if len(args) != 2 {
		return shim.Error("参数长度必须为2(身份证号,信用級別")
	}
	// 身份证号
	id_card := args[0]
	// 信用級別
	step := args[1]


	err := stub.PutState(id_card,[]byte(step))

	if err != nil {
		return shim.Error("写入账本失败")
	}

	return shim.Success([]byte("初始化成功"))
}

// 新增
func (p *CreditCc)setValue(stub shim.ChaincodeStubInterface,args []string) pb.Response   {

	if len(args) != 2 {
		return shim.Error("参数长度必须为2(身份证号,信用級別")
	}
	// 身份证号
	id_card := args[0]
	// 信用級別
	step := args[1]

	// 如果账本中没有该用户则新增，否则返回错误
	rsp,err := stub.GetState(id_card)

	// 注意：key不存在也不会报错，但是返回的空的
	if string(rsp) != "" {  // 表示存在
		return shim.Error("该房屋编号已存在")
	}

	err = stub.PutState(id_card,[]byte(step))

	if err != nil {
		return shim.Error("新增失败")
	}

	return shim.Success([]byte("新增成功"))

}

// 查询：身份证号
func (p *CreditCc)query(stub shim.ChaincodeStubInterface,args []string) pb.Response  {

	if len(args) != 1 {
		return shim.Error("参数必须为身份证号，参数个数为1")
	}

	id_card := args[0]


	id_card_byte,err := stub.GetState(id_card)

	if err != nil {
		return shim.Error("没有该身份证号")
	}

	return shim.Success(id_card_byte)
}


func (p *CreditCc)Invoke(stub shim.ChaincodeStubInterface) pb.Response  {

	f,args := stub.GetFunctionAndParameters()

	if f == "set" {
		return p.setValue(stub,args)
	}

	if f == "query" {
		return p.query(stub,args)
	}

	return shim.Error("函数名称错误，只能是set或query")
}


func main() {
	err := shim.Start(new(CreditCc))

	if err != nil {
		fmt.Println("启动fabric发生错误")
	}
}
