package main

import (
	pb "github.com/hyperledger/fabric/protos/peer"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"fmt"
)
type PoliceCc struct {}

/*
	64xxx,zs,18,xxx地址
 */
func (p *PoliceCc)Init(stub shim.ChaincodeStubInterface) pb.Response {
	_,args := stub.GetFunctionAndParameters()

	if len(args) != 4 {
		return shim.Error("参数长度必须为4(身份证号，姓名，年龄，住址)")
	}
	// 身份证号
	id_card := args[0]
	// 姓名
	name := args[1]
	// 年龄
	age := args[2]
	// 住址
	addr := args[3]

	value := fmt.Sprintf(`{"name":"%s","age":"%s","addr":"%s"}`,name,age,addr)
	err := stub.PutState(id_card,[]byte(value))

	if err != nil {
		return shim.Error("写入账本失败")
	}

	return shim.Success([]byte("初始化成功"))
}

// 新增
func (p *PoliceCc)setValue(stub shim.ChaincodeStubInterface,args []string) pb.Response   {

	if len(args) != 4 {
		return shim.Error("参数长度必须为4(身份证号，姓名，年龄，住址)")
	}
	// 身份证号
	id_card := args[0]
	// 姓名
	name := args[1]
	// 年龄
	age := args[2]
	// 住址
	addr := args[3]

	// 如果账本中没有该用户才新增，否则返回错误
	rsp,err := stub.GetState(id_card)

	// 注意：key不存在也不会报错，但是返回的空的
	if string(rsp) != "" {  // 表示存在
		return shim.Error("该身份证号已存在")
	}

	value := fmt.Sprintf(`{"name":"%s","age":"%s","addr":"%s"}`,name,age,addr)
	err = stub.PutState(id_card,[]byte(value))

	if err != nil {
		return shim.Error("新增失败")
	}

	return shim.Success([]byte("新增成功"))

}

// 查询
func (p *PoliceCc)query(stub shim.ChaincodeStubInterface,args []string) pb.Response  {

	if len(args) != 1 {
		return shim.Error("参数必须为身份证号，参数个数为1")
	}

	id_card := args[0]


	id_card_byte,err := stub.GetState(id_card)

	if err != nil {
		return shim.Error("没有该身份证号")
	}

	return shim.Success(id_card_byte)
}


func (p *PoliceCc)Invoke(stub shim.ChaincodeStubInterface) pb.Response  {

	f,args := stub.GetFunctionAndParameters()

	if f == "set" {
		return p.setValue(stub,args)
	}

	if f == "query" {
		return p.query(stub,args)
	}

	return shim.Error("函数名称错误，只能是set或query")
}


func main() {
	err := shim.Start(new(PoliceCc))

	if err != nil {
		fmt.Println("启动fabric发生错误")
	}
}
