package main

import (
	pb "github.com/hyperledger/fabric/protos/peer"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"fmt"
)

type TxCc struct {}

/*
	交易管理链码：
		key：订单编号-期数
		value：订单编号，分期,房东姓名，房东身份证号,租户姓名，租户身份证号，
			房屋编号，租金，交易时间
			合同编号，备注(描述)
 */
func (p *TxCc)Init(stub shim.ChaincodeStubInterface) pb.Response {
	_,args := stub.GetFunctionAndParameters()

	if len(args) != 11 {
		return shim.Error("参数长度必须为11")
	}

	// 订单编号
	orderId := args[0]
	// 分期期数
	qs := args[1]
	// 房东姓名
	fd_name := args[2]
	// 房东身份证号
	fd_idcard := args[3]
	// 租户姓名
	zh_name := args[4]
	// 租户身份证号
	zh_idcard := args[5]
	// 房屋编号
	fwbh := args[6]
	// 租金
	zj := args[7]
	// 交易时间
	jysj := args[8]
	// 合同编号
	htbh := args[9]
	// 备注
	desc := args[10]


	// 订单编号-期数
	orderId_qs := fmt.Sprintf("%s-%s",orderId,qs)

	value := fmt.Sprintf(`{"orderId":"%s","qs":"%s","fd_name":"%s","fd_idcard":"%s","zh_name":"%s","zh_idcard":"%s","fwbh":"%s","zj":"%s","jysj":"%s","htbh":"%s","desc":"%s"}`,orderId,qs,fd_name,fd_idcard,zh_name,zh_idcard,fwbh,zj,jysj,htbh,desc)
	err := stub.PutState(orderId_qs,[]byte(value))

	if err != nil {
		return shim.Error("写入账本失败")
	}

	return shim.Success([]byte("初始化成功"))
}

// 新增
func (p *TxCc)setValue(stub shim.ChaincodeStubInterface,args []string) pb.Response   {

	if len(args) != 12 {
		return shim.Error("参数长度必须为12")
	}
	// 订单编号-期数
	orderId_qs := args[0]
	// 订单编号
	orderId := args[1]
	// 分期期数
	qs := args[2]
	// 房东姓名
	fd_name := args[3]
	// 房东身份证号
	fd_idcard := args[4]
	// 租户姓名
	zh_name := args[5]
	// 租户身份证号
	zh_idcard := args[6]
	// 房屋编号
	fwbh := args[7]
	// 租金
	zj := args[8]
	// 交易时间
	jysj := args[9]
	// 合同编号
	htbh := args[10]
	// 备注
	desc := args[11]




	// 如果账本中没有该订单编号-期数则新增，否则返回错误
	rsp,err := stub.GetState(orderId_qs)

	// 注意：key不存在也不会报错，但是返回的空的
	if string(rsp) != "" {  // 表示存在
		return shim.Error("该订单编号-期数已存在")
	}

	value := fmt.Sprintf(`{"orderId":"%s","qs":"%s","fd_name":"%s","fd_idcard":"%s","zh_name":"%s","zh_idcard":"%s","fwbh":"%s","zj":"%s","jysj":"%s","htbh":"%s","desc":"%s"}`,orderId,qs,fd_name,fd_idcard,zh_name,zh_idcard,fwbh,zj,jysj,htbh,desc)
	err = stub.PutState(orderId_qs,[]byte(value))

	if err != nil {
		return shim.Error("新增失败")
	}

	return shim.Success([]byte("新增成功"))

}

// 查询：订单编号-期数
func (p *TxCc)query(stub shim.ChaincodeStubInterface,args []string) pb.Response  {


	if len(args) != 1 {
		return shim.Error("参数必须为订单编号-期数，参数个数为1")
	}

	orderId_qs := args[0]


	orderId_qs_byte,err := stub.GetState(orderId_qs)

	if err != nil {
		return shim.Error("没有该订单编号-期数")
	}

	return shim.Success(orderId_qs_byte)
}


func (p *TxCc)Invoke(stub shim.ChaincodeStubInterface) pb.Response  {

	f,args := stub.GetFunctionAndParameters()

	if f == "set" {
		return p.setValue(stub,args)
	}

	if f == "query" {
		return p.query(stub,args)
	}

	return shim.Error("函数名称错误，只能是set或query")
}


func main() {
	err := shim.Start(new(TxCc))

	if err != nil {
		fmt.Println("启动fabric发生错误")
	}
}
