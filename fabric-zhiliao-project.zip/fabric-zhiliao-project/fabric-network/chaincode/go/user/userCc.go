package main

import (
	pb "github.com/hyperledger/fabric/protos/peer"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"fmt"
)
type UserCc struct {}

/*
	账号管理：
		角色，1：police，2：authority，3：credit，4：个人
		用户名
		密码
		年龄
		性别
	key：用户名-密码-角色-年龄-性别

 */
func (p *UserCc)Init(stub shim.ChaincodeStubInterface) pb.Response {
	_,args := stub.GetFunctionAndParameters()

	if len(args) != 5 {
		return shim.Error("参数长度必须为5(角色,用户名,密码,年龄,性别)")
	}
	// 角色
	role := args[0]
	// 用户名
	username := args[1]
	// 密码
	pwd := args[2]
	// 年龄
	age := args[3]
	// 性别
	gender := args[4]

	value := fmt.Sprintf(`{"role":"%s","username":"%s","pwd":"%s","age":"%s","gender":"%s"}`,role,username,pwd,age,gender)
	k := fmt.Sprintf("%s-%s-%s",username,pwd,role)
	err := stub.PutState(k,[]byte(value))

	if err != nil {
		return shim.Error("写入账本失败")
	}

	return shim.Success([]byte("初始化成功"))
}

// 新增
func (p *UserCc)setValue(stub shim.ChaincodeStubInterface,args []string) pb.Response   {

	if len(args) != 5 {
		return shim.Error("参数长度必须为5(角色,用户名,密码,年龄,性别)")
	}
	// 角色
	role := args[0]
	// 用户名
	username := args[1]
	// 密码
	pwd := args[2]
	// 年龄
	age := args[3]
	// 性别
	gender := args[4]

	// 如果账本中没有该用户才新增，否则返回错误
	k := fmt.Sprintf("%s-%s-%s",username,pwd,role)
	rsp,err := stub.GetState(k)

	// 注意：key不存在也不会报错，但是返回的空的
	if string(rsp) != "" {  // 表示存在
		return shim.Error("该用户已存在")
	}

	value := fmt.Sprintf(`{"role":"%s","username":"%s","pwd":"%s","age":"%s","gender":"%s"}`,role,username,pwd,age,gender)
	err = stub.PutState(k,[]byte(value))

	if err != nil {
		return shim.Error("新增失败")
	}

	return shim.Success([]byte("新增成功"))

}

// 查询
func (p *UserCc)query(stub shim.ChaincodeStubInterface,args []string) pb.Response  {

	if len(args) != 1 {
		return shim.Error("参数必须为<用户名-密码-角色>，参数个数为1")
	}

	user := args[0]


	user_byte,err := stub.GetState(user)

	if err != nil {
		return shim.Error("没有该用户")
	}

	return shim.Success(user_byte)
}


func (p *UserCc)Invoke(stub shim.ChaincodeStubInterface) pb.Response  {

	f,args := stub.GetFunctionAndParameters()

	if f == "set" {
		return p.setValue(stub,args)
	}

	if f == "query" {
		return p.query(stub,args)
	}

	return shim.Error("函数名称错误，只能是set或query")
}


func main() {
	err := shim.Start(new(UserCc))

	if err != nil {
		fmt.Println("启动fabric发生错误")
	}
}
