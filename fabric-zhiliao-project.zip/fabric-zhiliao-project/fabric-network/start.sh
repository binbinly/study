#!/bin/bash
echo "第一步：下载镜像开始..."

#./download-dockerimages.sh   # 这个下载镜像有问题，换成下面命令

#docker pull hyperledger/fabric-tools:x86_64-1.0.0
#docker pull hyperledger/fabric-orderer:x86_64-1.0.0
#docker pull hyperledger/fabric-peer:x86_64-1.0.0
#docker pull hyperledger/fabric-couchdb:x86_64-1.0.0
#docker pull hyperledger/fabric-kafka:x86_64-1.0.0
#docker pull hyperledger/fabric-ca:x86_64-1.0.0
#docker pull hyperledger/fabric-ccenv:x86_64-1.0.0
#docker pull hyperledger/fabric-baseimage:x86_64-0.4.7
#docker pull hyperledger/fabric-javaenv:x86_64-1.0.0
#docker pull hyperledger/fabric-zookeeper:x86_64-1.0.0

#docker tag hyperledger/fabric-tools:x86_64-1.0.0 hyperledger/fabric-tools
#docker tag hyperledger/fabric-orderer:x86_64-1.0.0 hyperledger/fabric-orderer
#docker tag hyperledger/fabric-peer:x86_64-1.0.0 hyperledger/fabric-peer
#docker tag hyperledger/fabric-couchdb:x86_64-1.0.0 hyperledger/fabric-couchdb
#docker tag hyperledger/fabric-kafka:x86_64-1.0.0 hyperledger/fabric-kafka
#docker tag hyperledger/fabric-ca:x86_64-1.0.0 hyperledger/fabric-ca
#docker tag hyperledger/fabric-ccenv:x86_64-1.0.0 hyperledger/fabric-ccenv
#docker tag hyperledger/fabric-baseimage:x86_64-0.4.7 hyperledger/fabric-baseimage
#docker tag hyperledger/fabric-javaenv:x86_64-1.0.0 hyperledger/fabric-javaenv
#docker tag hyperledger/fabric-zookeeper:x86_64-1.0.0 hyperledger/fabric-zookeeper
echo "下载镜像完成"

echo "第二步:生成证书开始..."
cryptogen generate --config ./crypto-config.yaml
echo "生成证书结束"

echo "第三步:生成创世块及通道开始..."
mkdir channel-artifacts
configtxgen -profile GenGenesis -outputBlock ./channel-artifacts/genesis.block

configtxgen -profile GenChannel -channelID policechannel -outputCreateChannelTx ./channel-artifacts/policechannel.tx
configtxgen -profile GenChannel -channelID authoritychannel -outputCreateChannelTx ./channel-artifacts/authoritychannel.tx
configtxgen -profile GenChannel -channelID creditchannel -outputCreateChannelTx ./channel-artifacts/creditchannel.tx
echo "生成创世块及通道完成"

echo "第四步:启动docker-compose开始..."
docker-compose -f ./docker-compose-cli.yaml up -d
echo "启动docker-compose结束"

# 启动docker-compose需要点时间，给5秒
sleep 5

echo "第六步:创建通道开始..."
docker exec cli_police peer channel create -o orderer.zhiliao.com:7050 -c policechannel -f /opt/gopath/src/github.com/hyperledger/fabric/peer/channel-artifacts/policechannel.tx --tls true --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/zhiliao.com/msp/tlscacerts/tlsca.zhiliao.com-cert.pem
docker exec cli_authority peer channel create -o orderer.zhiliao.com:7050 -c authoritychannel -f /opt/gopath/src/github.com/hyperledger/fabric/peer/channel-artifacts/authoritychannel.tx --tls true --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/zhiliao.com/msp/tlscacerts/tlsca.zhiliao.com-cert.pem
docker exec cli_credit peer channel create -o orderer.zhiliao.com:7050 -c creditchannel -f /opt/gopath/src/github.com/hyperledger/fabric/peer/channel-artifacts/creditchannel.tx --tls true --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/zhiliao.com/msp/tlscacerts/tlsca.zhiliao.com-cert.pem
echo  "创建通道结束"

echo "拷贝生成的block文件到宿主机"
docker cp cli_police:/opt/gopath/src/github.com/hyperledger/fabric/peer/policechannel.block /home/zhiliao/go/workspace/src/fabric-zhiliao-project/fabric-network/
docker cp cli_authority:/opt/gopath/src/github.com/hyperledger/fabric/peer/authoritychannel.block /home/zhiliao/go/workspace/src/fabric-zhiliao-project/fabric-network/
docker cp cli_credit:/opt/gopath/src/github.com/hyperledger/fabric/peer/creditchannel.block /home/zhiliao/go/workspace/src/fabric-zhiliao-project/fabric-network/

echo "拷贝block文件到新的宿主机"
docker cp /home/zhiliao/go/workspace/src/fabric-zhiliao-project/fabric-network/policechannel.block cli_police1:/opt/gopath/src/github.com/hyperledger/fabric/peer/
docker cp /home/zhiliao/go/workspace/src/fabric-zhiliao-project/fabric-network/authoritychannel.block cli_authority1:/opt/gopath/src/github.com/hyperledger/fabric/peer/
docker cp /home/zhiliao/go/workspace/src/fabric-zhiliao-project/fabric-network/creditchannel.block cli_credit1:/opt/gopath/src/github.com/hyperledger/fabric/peer/



echo "第七步:当前peer节点加入通道开始..."
docker exec cli_police peer channel join -b policechannel.block
docker exec cli_police1 peer channel join -b policechannel.block

docker exec cli_authority peer channel join -b authoritychannel.block
docker exec cli_authority1 peer channel join -b authoritychannel.block

docker exec cli_credit peer channel join -b creditchannel.block
docker exec cli_credit1 peer channel join -b creditchannel.block
echo "当前peer节点加入结束"


echo "第八步:链码安装开始..."
docker exec cli_police peer chaincode install -n policeCc -v 1.0 -p github.com/hyperledger/fabric/chaincode/go/police
docker exec cli_police1 peer chaincode install -n policeCc -v 1.0 -p github.com/hyperledger/fabric/chaincode/go/police

docker exec cli_authority peer chaincode install -n authorityCc -v 1.0 -p github.com/hyperledger/fabric/chaincode/go/authority
docker exec cli_authority1 peer chaincode install -n authorityCc -v 1.0 -p github.com/hyperledger/fabric/chaincode/go/authority

docker exec cli_credit peer chaincode install -n creditCc -v 1.0 -p github.com/hyperledger/fabric/chaincode/go/credit
docker exec cli_credit1 peer chaincode install -n creditCc -v 1.0 -p github.com/hyperledger/fabric/chaincode/go/credit

docker exec cli_credit peer chaincode install -n contractCc -v 1.0 -p github.com/hyperledger/fabric/chaincode/go/contract
docker exec cli_credit1 peer chaincode install -n contractCc -v 1.0 -p github.com/hyperledger/fabric/chaincode/go/contract

docker exec cli_credit peer chaincode install -n txCc -v 1.0 -p github.com/hyperledger/fabric/chaincode/go/tx
docker exec cli_credit1 peer chaincode install -n txCc -v 1.0 -p github.com/hyperledger/fabric/chaincode/go/tx

docker exec cli_credit peer chaincode install -n userCc -v 1.0 -p github.com/hyperledger/fabric/chaincode/go/user
docker exec cli_credit1 peer chaincode install -n userCc -v 1.0 -p github.com/hyperledger/fabric/chaincode/go/user
echo "链码安装结束"

echo "第九步:链码初始化开始..."
docker exec cli_police peer chaincode instantiate -o orderer.zhiliao.com:7050 -C policechannel -c '{"Args":["init","6411111111312312931","hallen","18","xxx-address"]}' -n policeCc -P "OR ('PoliceMSP.member')" -v 1.0 --tls true --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/zhiliao.com/msp/tlscacerts/tlsca.zhiliao.com-cert.pem
docker exec cli_authority peer chaincode instantiate -o orderer.zhiliao.com:7050 -C authoritychannel -c '{"Args":["init","fwbh-123131241","fw-hallen","fw-xxxx","zhufang"]}' -n authorityCc -P "OR ('AuthorityMSP.member')" -v 1.0 --tls true --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/zhiliao.com/msp/tlscacerts/tlsca.zhiliao.com-cert.pem
docker exec cli_credit peer chaincode instantiate -o orderer.zhiliao.com:7050 -C creditchannel -c '{"Args":["init","123123131241X","A"]}' -n creditCc -P "OR ('CreditMSP.member')" -v 1.0 --tls true --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/zhiliao.com/msp/tlscacerts/tlsca.zhiliao.com-cert.pem
docker exec cli_credit peer chaincode instantiate -o orderer.zhiliao.com:7050 -C creditchannel -c '{"Args":["init","ht-13123123","312312314441X","fw-3123ddad","ddasdqeqe1123123123"]}' -n contractCc -P "OR ('CreditMSP.member')" -v 1.0 --tls true --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/zhiliao.com/msp/tlscacerts/tlsca.zhiliao.com-cert.pem
docker exec cli_credit peer chaincode instantiate -o orderer.zhiliao.com:7050 -C creditchannel -c '{"Args":["init","order-13123123","4","ls","1123123123X","ww","3123141113","fw-eqwe1312","1000","2021-06-01 16:56:24","ht-dqeeq113","test"]}' -n txCc -P "OR ('CreditMSP.member')" -v 1.0 --tls true --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/zhiliao.com/msp/tlscacerts/tlsca.zhiliao.com-cert.pem
docker exec cli_credit peer chaincode instantiate -o orderer.zhiliao.com:7050 -C creditchannel -c '{"Args":["init","4","hallen","123456","18","female"]}' -n userCc -P "OR ('CreditMSP.member')" -v 1.0 --tls true --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/zhiliao.com/msp/tlscacerts/tlsca.zhiliao.com-cert.pem
echo "链码初始化结束"
