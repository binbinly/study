package main

import (
	police "fabric-zhiliao-project/application/sdk/police"
	"fmt"
	authority "fabric-zhiliao-project/application/sdk/authority"
	credit "fabric-zhiliao-project/application/sdk/credit"
)

// police-sdk测试
func TestPoliceSdk()  {

	chaincode_name := "policeCc"
	fcn := "query"
	args := [][]byte{[]byte("6411111111312312931")}
	rsp,err := police.ChannelQuery(chaincode_name,fcn,args)
	if error.Error(err) == "Client Status Code: (5) TIMEOUT. Description: request timed out or been cancelled"{
		fmt.Println("已经添加成功")
	}else {
		fmt.Println("添加失败")
	}

	fmt.Println("===================police-sdk测试")
	fmt.Println(rsp)
}

// authority-sdk
func TestAuthoritySdk()  {
	chaincode_name := "authorityCc"
	fcn := "query"
	args := [][]byte{[]byte("fwbh-123131241")}
	rsp,err := authority.ChannelQuery(chaincode_name,fcn,args)

	if error.Error(err) == "Client Status Code: (5) TIMEOUT. Description: request timed out or been cancelled"{
		fmt.Println("已经添加成功")
	}else {
		fmt.Println("添加失败")
	}

	fmt.Println("===================authority-sdk测试")
	fmt.Println(rsp)
	fmt.Println(rsp.ChaincodeStatus)
	fmt.Println(string(rsp.Payload))

}

// credit-sdk
func TestCreditSdk()  {
	chaincode_name := "creditCc"
	//fcn := "query"
	//args := [][]byte{[]byte("123123131241X")}
	//rsp := credit.ChannelQuery(chaincode_name,fcn,args)
	//fmt.Println("==============credit-sdk测试")
	//fmt.Println(rsp.ChaincodeStatus)
	//fmt.Println(string(rsp.Payload))
	//
	//
	fcn_set := "set"
	set_args := [][]byte{[]byte("6666"),[]byte("B")}
	rsp_set,err := credit.ChannelExecute(chaincode_name,fcn_set,set_args)

	if error.Error(err) == "Client Status Code: (5) TIMEOUT. Description: request timed out or been cancelled"{
		fmt.Println("已经添加成功")
	}else {
		fmt.Println("添加失败")
	}
	fmt.Println(rsp_set.ChaincodeStatus)


	fcn := "query"
	args2 := [][]byte{[]byte("6666")}
	rsp2,err := credit.ChannelQuery(chaincode_name,fcn,args2)
	if error.Error(err) == "Client Status Code: (5) TIMEOUT. Description: request timed out or been cancelled"{
		fmt.Println("已经添加成功")
	}else {
		fmt.Println("添加失败")
	}
	fmt.Println(rsp2.ChaincodeStatus)
	fmt.Println(string(rsp2.Payload))


}

// contract-sdk
func TestContractSdk()  {
	chaincode_name := "contractCc"
	fcn := "query"
	args := [][]byte{[]byte("ht-13123123")}
	rsp,err := credit.ChannelQuery(chaincode_name,fcn,args)

	if error.Error(err) == "Client Status Code: (5) TIMEOUT. Description: request timed out or been cancelled"{
		fmt.Println("已经添加成功")
	}else {
		fmt.Println("添加失败")
	}

	fmt.Println("==============contract-sdk测试")
	fmt.Println(rsp.ChaincodeStatus)
	fmt.Println(string(rsp.Payload))

}

// tx-sdk
func TestTxSdk()  {
	chaincode_name := "txCc"
	fcn := "query"
	args := [][]byte{[]byte("order-13123123-4")}
	rsp,err := credit.ChannelQuery(chaincode_name,fcn,args)
	if error.Error(err) == "Client Status Code: (5) TIMEOUT. Description: request timed out or been cancelled"{
		fmt.Println("已经添加成功")
	}else {
		fmt.Println("添加失败")
	}

	fmt.Println("==============tx-sdk测试")
	fmt.Println(rsp.ChaincodeStatus)
	fmt.Println(string(rsp.Payload))

}

// user-sdk
func TestUserSdk()  {
	chaincode_name := "userCc"
	fcn := "query"
	args := [][]byte{[]byte("hallen-123456-4-18-female")}
	rsp,err := credit.ChannelQuery(chaincode_name,fcn,args)
	if error.Error(err) == "Client Status Code: (5) TIMEOUT. Description: request timed out or been cancelled"{
		fmt.Println("已经添加成功")
	}else {
		fmt.Println("添加失败")
	}

	fmt.Println("==============user-sdk测试")
	fmt.Println(rsp.ChaincodeStatus)
	fmt.Println(string(rsp.Payload))




}

func main() {
	// police-sdk测试
	TestPoliceSdk()

	// authority-sdk测试
	//TestAuthoritySdk()

	TestCreditSdk()
	//TestContractSdk()
	//
	//TestTxSdk()
	//
	//TestUserSdk()


}


