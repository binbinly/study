<template>

<el-container style="margin-top: -60px;">
    <el-header style="padding: 0;">
      <el-menu
        :default-active="2"
        class="el-menu-demo"
        mode="horizontal"
        @select="handleSelect"
        background-color="#545c64"
        text-color="#fff"
        active-text-color="#ffd04b"
        router="true"
        
      >
        <el-menu-item>知了区块链租房网--房管局房屋添加</el-menu-item>
       
      </el-menu>
    </el-header>
    <el-main>
      <router-view></router-view>
    </el-main>
  </el-container>

  
  <el-row>
    <el-col :span="8"></el-col>
    <el-col :span="8">
      <h1 style="text-align: center; padding: 20px;">房管局房屋添加</h1>
      <el-form ref="form" :model="form">
        <el-form-item>
          <el-input v-model="form.bh" placeholder="房屋编号"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.syr" placeholder="房屋所有人"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.dz" placeholder="房屋地址"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.lx" placeholder="房屋类型"></el-input>
        </el-form-item>
       
        <el-form-item>
          <el-button type="primary" @click="onSubmit">提交</el-button>
        </el-form-item>
      </el-form>
    </el-col>
    <el-col :span="8"></el-col>
  </el-row>
</template>

<script>
import qs from "qs"
export default {
  name: "House",
  data: function() {
    return {
      form: {
        bh: "",
        syr: "",
        dz: "",
        lx: "",
      },
    };
  },
  methods:{
      onSubmit(){
      this.$axios.post("/authority/set",qs.stringify({
        bh:this.form.bh,
        syr:this.form.syr,
        dz:this.form.dz,
        lx:this.form.lx
      })).then(function(response){
    
          if(response.data.code == 200){
              alert(response.data.msg)

              window.location.href = "/authority_query"
              
          }else {
            alert(response.data.msg)
          }
          

      }).catch((data) => {
        console.log(data)
      })
    
  }
  }
};
</script>

<style></style>
