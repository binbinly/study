<template>


  <el-row>
    <el-col :span="8"></el-col>
    <el-col :span="8">
      <h1 style="text-align: center; padding: 20px;">合同管理--添加</h1>
      <el-form ref="form" :model="form">
        <el-form-item>
          <el-input
            placeholder="请输入身份证"
            v-model="form.id_card"
            class="input-with-select"
          >
            <template #append>
              <el-button icon="el-icon-search" type="primary" @click="geren_verify">认证</el-button>
            </template>
          </el-input>
        </el-form-item>
        <el-form-item>
          <el-input
            placeholder="请输入房屋编号"
            v-model="form.bh"
            class="input-with-select"
          >
            <template #append>
              <el-button icon="el-icon-search" type="primary" @click="fangwu_verify">认证</el-button>
            </template>
          </el-input>
        </el-form-item>


        <el-form-item>
          <el-input
            placeholder="请输入合同编号"
            v-model="form.htbh"
            class="input-with-select"
          >
          </el-input>
        </el-form-item>

        

        <el-form-item>
          <el-upload
            class="upload-demo"
            drag
            action="填写上传的url"
            accept=".jpg,.png,.gif"
            multiple
            :before-upload="onSubmit"
          >
            <i class="el-icon-upload"></i>
            <div class="el-upload__text">
              将合同文件拖到此处，或<em>点击上传</em>
            </div>
            <template #tip>
              <div class="el-upload__tip">
                只能上传 img/png/gif 文件，且不超过 500kb
              </div>
            </template>
          </el-upload>
        </el-form-item>
        <!-- <el-form-item>
          <el-button type="primary" @click="onSubmit">提交</el-button>
        </el-form-item> -->
      </el-form>
    </el-col>
    <el-col :span="8"></el-col>
  </el-row>
</template>

<script>
export default {
  name: "Contract",
  data: function() {
    return {
      form: {
        id_card: "",
        bh: "",
        htbh:""
      },
      ret_geren:false,
      ret_fangwu:false
    };
  },
  methods:{
    geren_verify(){
      this.$axios.get("/police/query",{
        params:{
          id_card:this.form.id_card
        }
      }).then((response) => {
        console.log(response)
        console.log(response.data.data)
          if (response.data.code == 200) {
            this.ret_geren = true
            alert("认证成功")
          }else{
            alert("认证失败")
          }
      })
    },

    fangwu_verify(){
      this.$axios.get("/authority/query",{
        params:{
          bh:this.form.bh
        }
      }).then((response) => {
        console.log(response)
        console.log(response.data.data)
          if (response.data.code == 200) {
            this.ret_fangwu = true
            alert("认证成功")
          }else{
            alert("认证失败")
          }
      })
    },

    onSubmit(file){
      if (this.ret_geren && this.ret_fangwu) {
        const formData = new FormData();
        formData.append("fwbh",this.form.bh)
        formData.append("htbh",this.form.htbh)
        formData.append("id_card",this.form.id_card)
        formData.append("contract_pic",file)

        this.$axios.post("/contract/set",formData).then(function(response){
            console.log(response)
            console.log(response.data)
            if (response.data.code == 200){
              alert(response.data.msg)
              window.location.href = "/geren/contract_query"
            }else {
              alert(response.data.msg)
            }
            
          
        }).catch((data) => {
          console.log(data)
        })


      }else{
        alert("个人认证或房屋认证未通过")
      }
     
    }
  }
};
</script>

<style></style>
