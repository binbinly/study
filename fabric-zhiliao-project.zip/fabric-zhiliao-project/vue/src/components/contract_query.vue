<template>
  <el-row>
    <el-col :span="6"></el-col>
    <el-col :span="12">

        <el-link href="/geren/contract_add"><el-button style="margin-left: -550px"  type="primary" icon="el-icon-plus" >添加</el-button></el-link>


        <div style="margin-top: 15px" >
            <el-input
                placeholder="请输入合同编号"
                v-model="form.htbh"
                class="input-with-select"
                prefix-icon="el-icon-search"
            >
                <template #append>
                <el-button type="primary" icon="el-icon-search" @click="query_contract">搜索</el-button>
                </template>
            </el-input>
            </div>



        <el-table :data="cotract_data" stripe style="width: 100%">
            <el-table-column prop="htbh" label="合同编号" width="180">
            </el-table-column>
            <el-table-column prop="id_card" label="租户身份证号" width="180">
            </el-table-column>
            <el-table-column prop="fwbh" label="房屋编号"> </el-table-column>
            <el-table-column prop="ht_hash" label="合同图片hash"> </el-table-column>
        </el-table>
    </el-col>
    <el-col :span="6"></el-col>
  </el-row>
</template>

<script>
export default {
  name: "Index",
  data() {
    return {
      form:{
        htbh:""
      },
      cotract_data: [],
    };
  },

  methods:{
    query_contract(){

      this.$axios.get("/contract/query",{
        params:{
          htbh:this.form.htbh
        }
      }).then((response) => {
        console.log(response)
        console.log(response.data.data)
          if (response.data.code == 200) {
            this.cotract_data[0] = response.data.data
          }else{
            alert(response.data.msg)
          }
      })
    }
    
}
      

};
</script>

<style></style>
