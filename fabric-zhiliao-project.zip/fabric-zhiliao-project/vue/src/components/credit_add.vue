<template>

<el-container style="margin-top: -60px;">
    <el-header style="padding: 0;">
      <el-menu
        :default-active="2"
        class="el-menu-demo"
        mode="horizontal"
        @select="handleSelect"
        background-color="#545c64"
        text-color="#fff"
        active-text-color="#ffd04b"
        router="true"
        
      >
        <el-menu-item>知了区块链租房网--征信中心信息添加</el-menu-item>
       
      </el-menu>
    </el-header>
    <el-main>
      <router-view></router-view>
    </el-main>
  </el-container>

  
  <el-row>
    <el-col :span="8"></el-col>
    <el-col :span="8">
      <h1 style="text-align: center; padding: 20px;">征信中心信息添加</h1>
      <el-form ref="form" :model="form">
        <el-form-item>
          <el-input v-model="form.id_card" placeholder="请输入身份证号"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.step" placeholder="请输入信用級別"></el-input>
        </el-form-item>
        <el-form-item>

        </el-form-item>
       
        <el-form-item>
          <el-button type="primary" @click="onSubmit">提交</el-button>
        </el-form-item>
      </el-form>
    </el-col>
    <el-col :span="8"></el-col>
  </el-row>
</template>

<script>
import qs from "qs"
export default {
  name: "House",
  data: function() {
    return {
      form: {
        id_card: "",
        step: "",
      },
    };
  },
  methods:{
      onSubmit(){
      this.$axios.post("/credit/set",qs.stringify({
        id_card:this.form.id_card,
        step:this.form.step,
      })).then(function(response){
    
          if(response.data.code == 200){
              alert(response.data.msg)

              window.location.href = "/credit_query"
              
          }else {
            alert(response.data.msg)
          }
          

      }).catch((data) => {
        console.log(data)
      })
    
  }
  }
};
</script>

<style></style>
