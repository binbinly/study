<template>
<el-container style="margin-top: -60px;">
    <el-header style="padding: 0;">
      <el-menu
        :default-active="2"
        class="el-menu-demo"
        mode="horizontal"
        @select="handleSelect"
        background-color="#545c64"
        text-color="#fff"
        active-text-color="#ffd04b"
        router="true"
      >
        <el-menu-item>知了区块链租房网--征信中心信息管理</el-menu-item>
       
      </el-menu>
    </el-header>
    <el-main>
      <router-view></router-view>
    </el-main>
  </el-container>

  <el-row>
    <el-col :span="6"></el-col>
    <el-col :span="12">

        <el-link href="/credit_add"><el-button style="margin-left: -550px"  type="primary" icon="el-icon-plus" >添加</el-button></el-link>


        <div style="margin-top: 15px" >
            <el-input
                placeholder="请输入身份证号"
                v-model="form.id_card"
                class="input-with-select"
                prefix-icon="el-icon-search"
            >
                <template #append>
                <el-button type="primary" icon="el-icon-search" @click="query_credit">搜索</el-button>
                </template>
            </el-input>
            </div>



        <el-table :data="credit_data" stripe style="width: 100%">
            <el-table-column prop="id_card" label="身份证号" width="180">
            </el-table-column>
            <el-table-column prop="step" label="信用級別" width="180">
            </el-table-column>
        </el-table>
    </el-col>
    <el-col :span="6"></el-col>
  </el-row>
</template>

<script>
export default {
  name: "Index",
  data() {
    return {
      form:{
        id_card:""
      },
      credit_data: []
    };
  },
  methods:{
    query_credit(){
      this.$axios.get("/credit/query",{
        params:{
          id_card:this.form.id_card
        }
      }).then((response) => {
          if (response.data.code == 200) {
            this.credit_data[0] = response.data.data
          }else{
            alert(response.data.msg)
          }
      })
    }
  }
};
</script>

<style></style>
