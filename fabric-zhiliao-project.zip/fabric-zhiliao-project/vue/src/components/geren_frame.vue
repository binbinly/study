<template>
  <el-container style="margin-top: -60px;">
    <el-header style="padding: 0;">
      <el-menu
        :default-active="1"
        class="el-menu-demo"
        mode="horizontal"
        @select="handleSelect"
        background-color="#545c64"
        text-color="#fff"
        active-text-color="#ffd04b"
        router="true"
      >
        <el-menu-item>知了区块链租房网--个人中心</el-menu-item>
        <el-menu-item index="1" :route="{name: 'contract_query'}">合同管理</el-menu-item>
        <el-menu-item index="2" :route="{name: 'tx_query'}">交易管理管理</el-menu-item>
      </el-menu>
    </el-header>
    <el-main>
      <router-view></router-view>
    </el-main>
  </el-container>
</template>

<script>
export default {
  name: "Frame",
};
</script>

<style scoped></style>
