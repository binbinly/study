<template>
  <el-row>
    <el-col :span="8"></el-col>
    <el-col :span="8">
      <h1 style="text-align: center; padding: 10px;">知了区块链租房网--注册</h1>
      <el-form ref="form" :model="form">

        <el-form-item>
            
            <el-radio-group v-model="form.role">
                <el-radio label="4">个人</el-radio>
                <el-radio label="1">公安局</el-radio>
                <el-radio label="2">房管局</el-radio>
                <el-radio label="3">征信中心</el-radio>
            
            </el-radio-group>
        </el-form-item>

      <!-- 个人有 -->
        <el-form-item>
          <el-input
            v-model="form.id_card"
            placeholder="请输入身份证号"
          ></el-input>
        </el-form-item>


        <el-form-item>
          <el-input
            v-model="form.username"
            placeholder="请输入用户名"
          ></el-input>
        </el-form-item>
        <el-form-item>
          <el-input
            v-model="form.pwd"
            show-password
            placeholder="请输入密码"
          ></el-input>
        </el-form-item>
        <!-- <el-form-item>
          <el-input
            v-model="form.password_confirm"
            show-password
            placeholder="请输入密码"
          ></el-input>
        </el-form-item> -->

         <el-form-item>
          <el-input
            v-model="form.age"
            placeholder="请输入年龄"
          ></el-input>
        </el-form-item>

         <el-form-item>
          <el-input
            v-model="form.gender"
            placeholder="请输入性别"
          ></el-input>
        </el-form-item>


        <el-form-item>
          <el-button type="primary" @click="onSubmit">注册</el-button>
        </el-form-item>
        <div>
          <el-link type="info" style="float: right;" href="/">有账号？立即登录</el-link>
        </div>
      </el-form>
    </el-col>
    <el-col :span="10"></el-col>
  </el-row>
</template>

<script>
import qs from "qs"

export default {
  name: "Register",
  data: function() {
    return {
      form: {
        role: "4",
        username: "",
        pwd: "",
        age: "",
        gender: "",
        id_card:"",
      },
    };
  },
  methods:{
    onSubmit(){
      this.$axios.post("/user/register",qs.stringify({
        username:this.form.username,
        role:this.form.role,
        pwd:this.form.pwd,
        age:this.form.age,
        gender:this.form.gender,
        id_card:this.form.id_card

      })).then(function(response){
          console.log(response)
          console.log(response.data)
          if (response.data.code == 200){
            alert(response.data.msg+",快去登录吧！")
            window.location.href = "/"
          }else {
            alert(1111)
            alert(response.data.msg)
          }
          
         
      }).catch((data) => {
        console.log(data)
      })
    }
  }
};
</script>

<style>
</style>
