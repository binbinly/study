<template>
  
  <el-row>
    <el-col :span="8"></el-col>
    <el-col :span="8">
      <h1 style="text-align: center; padding: 20px;">交易信息添加</h1>
      <el-form ref="form" :model="form">
        <el-form-item>
          <el-input v-model="form.orderId" placeholder="订单编号"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.qs" placeholder="分期期数"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.fd_name" placeholder="房东姓名"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.fd_idcard" placeholder="房东身份证号"></el-input>
        </el-form-item>

        <el-form-item>
          <el-input v-model="form.zh_name" placeholder="租户姓名"></el-input>
        </el-form-item>

        <el-form-item>
          <el-input v-model="form.zh_idcard" placeholder="租户身份证号"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.fwbh" placeholder="房屋编号"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.zj" placeholder="租金"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.jysj" placeholder="交易时间"></el-input>
        </el-form-item>

        <el-form-item>
          <el-input v-model="form.htbh" placeholder="合同编号"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.desc" placeholder="备注"></el-input>
        </el-form-item>
       
        <el-form-item>
          <el-button type="primary" @click="onSubmit">提交</el-button>
        </el-form-item>
      </el-form>
    </el-col>
    <el-col :span="8"></el-col>
  </el-row>
</template>

<script>
import qs from "qs"
export default {
  name: "House",
  data: function() {
    return {
      form: {
        orderId: "",
        qs: "",
        fd_name: "",
        fd_idcard: "",
        zh_name: "",
        zh_idcard: "",
        fwbh: "",
        zj: "",
        jysj: "",
        htbh: "",
        desc: "",
      },
    };
  },
  methods:{
      onSubmit(){
      this.$axios.post("/tx/set",qs.stringify({
        orderId:this.form.orderId,
        qs:this.form.qs,
        fd_name:this.form.fd_name,
        fd_idcard:this.form.fd_idcard,
        zh_name:this.form.zh_name,
        zh_idcard:this.form.zh_idcard,
        fwbh:this.form.fwbh,
        zj:this.form.zj,
        jysj:this.form.jysj,
        htbh:this.form.htbh,
        desc:this.form.desc,
      })).then(function(response){
    
          if(response.data.code == 200){
              alert(response.data.msg)

              window.location.href = "/geren/tx_query"
              
          }else {
            alert(response.data.msg)
          }
          

      }).catch((data) => {
        console.log(data)
      })
    
  }
  }
};
</script>

<style></style>
