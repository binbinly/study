<template>

  <el-row>
    <el-col :span="6"></el-col>
    <el-col :span="12">

        <el-link href="/geren/tx_add"><el-button style="margin-left: -550px"  type="primary" icon="el-icon-plus" >添加</el-button></el-link>


        <div style="margin-top: 15px" >
            <el-input
                placeholder="请输入订单编号"
                v-model="form.orderId"
                class="input-with-select"
                prefix-icon="el-icon-search"
            >
            </el-input>
            <el-input
                placeholder="请输入期数"
                v-model="form.qs"
                class="input-with-select"
                prefix-icon="el-icon-search"
            >
             <template #append>
                <el-button type="primary" icon="el-icon-search" @click="query_tx">搜索</el-button>
                </template>
               
            </el-input>

            
            </div>



        <el-table :data="tx_data" stripe style="width: 100%">
            <el-table-column prop="orderId" label="订单编号" width="180">
            </el-table-column>
            <el-table-column prop="qs" label="分期期数" width="180">
            </el-table-column>
            <el-table-column prop="fd_name" label="房东姓名"> </el-table-column>
            <el-table-column prop="fd_idcard" label="房东身份证号"> </el-table-column>
            <el-table-column prop="zh_name" label="租户姓名"> </el-table-column>
            <el-table-column prop="zh_idcard" label="租户身份证号"> </el-table-column>
            <el-table-column prop="fwbh" label="房屋编号"> </el-table-column>
            <el-table-column prop="zj" label="租金"> </el-table-column>
            <el-table-column prop="jysj" label="交易时间"> </el-table-column>
            <el-table-column prop="htbh" label="合同编号"> </el-table-column>
            <el-table-column prop="desc" label="备注"> </el-table-column>
        </el-table>
    </el-col>
    <el-col :span="6"></el-col>
  </el-row>
</template>

<script>
export default {
  name: "Index",
  data() {
    return {
      form:{
        orderId:"",
        qs:""
      },
      tx_data: [],
    };
  },

  methods:{
    query_tx(){

      this.$axios.get("/tx/query",{
        params:{
          orderId:this.form.orderId,
          qs:this.form.qs
        }
      }).then((response) => {
        console.log(response)
        console.log(response.data.data)
          if (response.data.code == 200) {
            this.tx_data[0] = response.data.data
          }else{
            alert(response.data.msg)
          }
      })
    }
    
}

};
</script>

<style></style>
