import {createRouter,createWebHistory} from 'vue-router'


import login from './components/login'
import register from './components/register'

import police_query from './components/police_query'
import police_add from './components/police_add'

import authority_query from './components/authority_query'
import authority_add from './components/authority_add'


import credit_query from './components/credit_query'
import credit_add from './components/credit_add'


import contract_query from './components/contract_query'
import contract_add from './components/contract_add'

import tx_query from './components/tx_query'
import tx_add from './components/tx_add'

import geren_frame from './components/geren_frame'


const webhistory = createWebHistory()




const my_router = [
    {
        path:'/',
        name:"login",
        component:login
    },
    {
        path:'/register',
        name:'register',
        component:register

    },

    {
        path:'/police_query',
        name:'police_query',
        component:police_query
    },
    {
        path:'/police_add',
        name:'police_add',
        component:police_add
    },

    {
        path:'/authority_query',
        name:'authority_query',
        component:authority_query
    },
    {
        path:'/authority_add',
        name:'authority_add',
        component:authority_add
    },

   
    {
        path:'/credit_query',
        name:'credit_query',
        component:credit_query
    },
    {
        path:'/credit_add',
        name:'credit_add',
        component:credit_add
    },


    {
        path:"/geren",
        component:geren_frame,
        children:[
            {
                path:'contract_query',
                name:'contract_query',
                component:contract_query
            },
            {
                path:'contract_add',
                name:'contract_add',
                component:contract_add
            },
        
            {
                path:'tx_query',
                name:'tx_query',
                component:tx_query
            },
            {
                path:'tx_add',
                name:'tx_add',
                component:tx_add
            },
        ]
    },
    
]


const router = createRouter({
    history:webhistory,
    routes:my_router
})


export default router
