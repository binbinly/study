package main

import (
	//"zlkt.net/security_project/utils"
	//"fmt"
)

func main() {

	// base64测试
	//src := "http://127.0.0.1:8080/?name=hello"
	//ret := utils.Base64Encoding(src)
	//ret := utils.Base64UrlEncoding(src)
	//fmt.Println(ret)


	//ret,err := utils.Base64decoding(ret)
	//ret,err := utils.Base64Urldecoding(ret)
	//
	//if err != nil {
	//	fmt.Println("解码发生错误了")
	//}
	//fmt.Println(ret)


	//ret_b58 := utils.Base58Encoding("he")
	//fmt.Println(ret_b58)
	//
	//
	//aa := utils.Base58Decoding("8wn")
	//fmt.Println(aa)

	//ret := utils.GenMd4("hallen")
	//ret2 := utils.GenMd5("hallen")
	//ret3 := utils.GenSha256("hallen")
	//fmt.Println(ret)
	//fmt.Println(ret2)
	//fmt.Println(ret3)

	//pwd,_ := utils.AesEncoding("hallen")
	//ret,_ := utils.AesDecoding(pwd)
	//fmt.Println(ret)

	//pwd,err := utils.TDesEncoding("hallen")
	//fmt.Println(err)
	//fmt.Println(pwd)
	//ret,err1 := utils.TDesDecoding(pwd)
	//fmt.Println(err1)
	//fmt.Println(ret)

	//utils.SaveRsaKey(2048)

	//ret,err := utils.RsaEncoding("hallen","publicKey.pem")
	//if err != nil {
	//	fmt.Println(err)
	//}
	//
	//fmt.Println(ret)
	//
	//ret_pri,err_pri := utils.RsaDecoding(ret,"privateKey.pem")
	//if err_pri != nil {
	//	fmt.Println(err_pri)
	//}


	//sign,err := utils.RsaGetSign("privateKey.pem","hallen")
	//fmt.Println(sign)
	//if err != nil {
	//	fmt.Println(err)
	//	panic("签名失败")
	//}
	//ok,err_varify := utils.RsaVarifySign(sign,"publicKey.pem","hallen")
	//
	//if err_varify != nil {
	//	fmt.Println(err_varify)
	//	panic("验证签名失败")
	//}
	//
	//fmt.Println(ok)



}
