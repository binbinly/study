package utils

import (
	"fmt"
	"math/big"
	"bytes"
)

var b58 = []byte("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz")
// base58编码
func Base58Encoding(src string) (string) {
	// he : 104 101 --> 104*256 + 101 = 26725

	// 26725 / 58 =   15 16 17

	// 1.ascii码对应的值

	src_byte := []byte(src)

	// 转成十进制
	 i := big.NewInt(0).SetBytes(src_byte)
	 fmt.Println(i)

	 var mod_slice []byte
	 // 循环取余
	 //for i.Cmp(big.NewInt(0)) != 0 {
	 for i.Cmp(big.NewInt(0)) > 0 {
	 	mod := big.NewInt(0)
	 	i58 := big.NewInt(58)
	 	// 取余
	 	i.DivMod(i,i58,mod)
	 	// 将余数添加到数组中
		 mod_slice = append(mod_slice, b58[mod.Int64()])
	 }

	 // 把0使用字节'1'代替
	 for _,s := range src_byte {
	 	if s != 0 {
	 		break
		}
		 mod_slice = append(mod_slice, byte('1'))
	 }

	// 反转byte数组
	//ret_mod_slice := ReverseByteArr(mod_slice)
	ret_mod_slice := ReverseByteArr2(mod_slice)
	fmt.Println(ret_mod_slice)
	return string(ret_mod_slice)
}

// byte数组进行反转方式1
func ReverseByteArr(b []byte) []byte{
	for i:=0; i<len(b)/2;i++ {
		b[i],b[len(b)-1-i] = b[len(b)-1-i],b[i]
	}
	return b
}

// byte数组进行反转方式2
func ReverseByteArr2(b []byte) []byte{
	for i,j:=0,len(b)-1;i<j;i,j = i+1,j-1{
		b[i] ,b[j] = b[j],b[i]

	}
	return b
}


// base58解码
func Base58Decoding(src string)  string{

	// 转成byte数组
	src_byte := []byte(src)
	//fmt.Println(src_byte)

	// 这里得到的是十进制
	ret := big.NewInt(0)
	for _, b := range src_byte {
		//fmt.Println(b)
		i := bytes.IndexByte(b58,b)
		fmt.Println(i)
		// 乘回去
		ret.Mul(ret,big.NewInt(58))
		// 相加
		ret.Add(ret,big.NewInt(int64(i)))

	}

	return  string(ret.Bytes())

}