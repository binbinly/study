package utils

import "encoding/base64"

// base64编码
func Base64Encoding(str string) (string) {
	src := []byte(str)
	ret := base64.StdEncoding.EncodeToString(src)
	return  ret

}

// base64解码
func Base64decoding(str string) (string,error) {

	ret_byte,err := base64.StdEncoding.DecodeString(str)
	ret := string(ret_byte)
	return ret,err

}


// url编码
func Base64UrlEncoding(str string) (string)  {
	src := []byte(str)
	ret := base64.URLEncoding.EncodeToString(src)

	return ret

}

// url解码
func Base64Urldecoding(str string) (string,error) {

	ret_byte,err := base64.URLEncoding.DecodeString(str)

	ret := string(ret_byte)
	return ret,err

}