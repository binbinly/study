package utils

import (
	"crypto/des"
	"encoding/base64"
)

// 只支持8字节的长度
var des_key []byte = []byte("hallenha")
// 3des的key，长度是24
var tdes_key []byte = []byte("hallenhallenhallenhallen")

// 加密
func DesEncoding(src string) (string,error) {

	src_byte := []byte(src)

	block ,err := des.NewCipher(des_key)
	if err != nil {
		return src,err
	}
	// 密码填充
	new_src_byte := PadPwd(src_byte,block.BlockSize())

	dst := make([]byte,len(new_src_byte))
	block.Encrypt(dst,new_src_byte)

	// base64编码
	pwd := base64.StdEncoding.EncodeToString(dst)

	return pwd,nil

}

// 解密
func DesDecoding(pwd string) (string,error)  {

	pwd_byte,err := base64.StdEncoding.DecodeString(pwd)


	if err != nil {
		return pwd,err
	}

	block,err_block := des.NewCipher(des_key)

	if err_block != nil {
		return pwd,err_block
	}

	dst := make([]byte,len(pwd_byte))
	block.Decrypt(dst,pwd_byte)

	// 填充的要去掉
	dst,_ = UnPadPwd(dst)

	return string(dst),nil

}


// 3des加密
func TDesEncoding(src string) (string,error) {

	src_byte := []byte(src)

	block ,err := des.NewTripleDESCipher(tdes_key)
	if err != nil {
		return src,err
	}
	// 密码填充
	new_src_byte := PadPwd(src_byte,block.BlockSize())

	dst := make([]byte,len(new_src_byte))
	block.Encrypt(dst,new_src_byte)

	// base64编码
	pwd := base64.StdEncoding.EncodeToString(dst)

	return pwd,nil

}


// 3des解密
func TDesDecoding(pwd string) (string,error)  {

	pwd_byte,err := base64.StdEncoding.DecodeString(pwd)


	if err != nil {
		return pwd,err
	}

	block,err_block := des.NewTripleDESCipher(tdes_key)

	if err_block != nil {
		return pwd,err_block
	}

	dst := make([]byte,len(pwd_byte))
	block.Decrypt(dst,pwd_byte)

	// 填充的要去掉
	dst,_ = UnPadPwd(dst)

	return string(dst),nil

}
