package utils

import (
	"golang.org/x/crypto/md4"
	"encoding/hex"
	"crypto/md5"
)

func GenMd4(src string)  string{

	src_bytes := []byte(src)

	md4_new := md4.New()
	md4_bytes := md4_new.Sum(src_bytes)

	md4_string := hex.EncodeToString(md4_bytes)
	return md4_string


}


func GenMd5(src string)  string{

	src_bytes := []byte(src)

	md5_new := md5.New()

	md5_bytes := md5_new.Sum(src_bytes)

	md5_string := hex.EncodeToString(md5_bytes)
	return md5_string

}
