package utils

import (
	"crypto/rsa"
	"crypto/rand"
	"fmt"
	"crypto/x509"
	"encoding/pem"
	"os"
)

// 保存生成的公钥和密钥
func SaveRsaKey(bits int)  (error){

	privateKey,err := rsa.GenerateKey(rand.Reader,bits)
	if err != nil {
		fmt.Println(err)
		return err
	}
	publicKey := privateKey.PublicKey

	// 使用x509标准对私钥进行编码，AsN.1编码字符串
	x509_privete := x509.MarshalPKCS1PrivateKey(privateKey)
	// 使用x509标准对公钥进行编码，AsN.1编码字符串
	x509_public := x509.MarshalPKCS1PublicKey(&publicKey)

	// 对私钥封装block 结构数据
	block_private := pem.Block{Type:"private key",Bytes:x509_privete}
	// 对公钥封装block 结构数据
	block_public := pem.Block{Type:"public key",Bytes:x509_public}

	// 创建存放私钥的文件
	privateFile,err_pri := os.Create("privateKey.pem")
	if err_pri != nil {
		return err_pri
	}
	defer privateFile.Close()
	pem.Encode(privateFile,&block_private)

	// 创建存放公钥的文件
	publicFile,err_pub := os.Create("publicKey.pem")
	if err_pub != nil {
		return err_pub
	}
	defer publicFile.Close()
	pem.Encode(publicFile,&block_public)


	return nil

}

// 加密
func RsaEncoding(src ,file_path string)  ([]byte,error){

	src_byte := []byte(src)

	// 打开文件
	file,err := os.Open(file_path)
	if err != nil {
		return src_byte,err
	}

	// 获取文件信息
	file_info,err_info := file.Stat()
	if err_info != nil {
		return src_byte,err_info
	}
	// 读取文件内容
	key_bytes := make([]byte,file_info.Size())
	// 读取内容到容器里面
	file.Read(key_bytes)

	// pem解码
	block,_ := pem.Decode(key_bytes)

	// x509解码
	publicKey ,err_pb := x509.ParsePKCS1PublicKey(block.Bytes)
	if err_pb != nil {
		return src_byte,err_pb
	}

	// 使用公钥对明文进行加密

	ret_byte,err_ret := rsa.EncryptPKCS1v15(rand.Reader,publicKey,src_byte)
	if err_ret != nil {
		return src_byte,err_ret
	}

	return ret_byte,nil


}

// 解密
func RsaDecoding(src_byte []byte,file_path string) ([]byte,error) {

	// 打开文件
	file,err := os.Open(file_path)
	if err != nil {
		return src_byte,err
	}

	// 获取文件信息
	file_info,err_info := file.Stat()
	if err_info != nil {
		return src_byte,err_info
	}
	// 读取文件内容
	key_bytes := make([]byte,file_info.Size())
	// 读取内容到容器里面
	file.Read(key_bytes)

	// pem解码
	block,_ := pem.Decode(key_bytes)

	// x509解码
	privateKey ,err_pb := x509.ParsePKCS1PrivateKey(block.Bytes)
	if err_pb != nil {
		return src_byte,err_pb
	}

	// 进行解密
	ret_byte, err_ret := rsa.DecryptPKCS1v15(rand.Reader,privateKey,src_byte)

	if err_ret != nil {
		return src_byte,err_ret
	}

	return ret_byte,nil


}
