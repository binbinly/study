package utils

import (
	"crypto/sha256"
	"encoding/hex"
)

func GenSha256(src string) string {
	src_bytes := []byte(src)

	sha256_new := sha256.New()
	sha256_bytes := sha256_new.Sum(src_bytes)

	sha256_string := hex.EncodeToString(sha256_bytes)
	return sha256_string


}
