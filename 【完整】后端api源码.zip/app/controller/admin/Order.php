<?php

namespace app\controller\admin;

use think\Request;
use app\controller\common\Base;
use think\facade\Db;
use think\facade\Queue;

use Flex\Express\ExpressBird;

use jianyan\excel\Excel;

class Order extends Base
{
    protected $excludeValidateCheck = ['excelexport'];
    
    // 发货
    public function ship(){
        $order = request()->Model;
        // 判断订单未付款
        if (!$order->paid_time) {
            ApiException('订单未付款');
        }
        // 判断订单是否关闭
        if ($order->closed) {
            ApiException('订单已关闭');
        }
        // 判断当前订单已发货
        if ($order->ship_status !== 'pending') {
            ApiException('订单已发货');
        }
        
        // 判断是否已退款
        if ($order->refund_status !== 'pending') {
            ApiException('订单已退款');
        }
        
        // 将订单发货状态改为已发货，并存入物流信息
        $param = request()->param();
        $order->ship_status = 'delivered';
        $order->ship_data = [
            'express_company'=>$param['express_company'],
            'express_no'=>$param['express_no'],
            'express_time'=>time()
        ];
        
        $result = $order->save();
        if($result){
        	// 触发自动确认收货任务
        	$delay = cmsConfig('auto_received_day');
        	if($delay){
        	    $delay = $delay * 24 * 60 * 60;
        	   Queue::later($delay,'autoReceived',[
                    'orderId'=>$order->id
                ]); 
        	}
        }
        
        return showSuccess($result);
    }


    // 拒绝/同意 申请退款
    public function handleRefund(){
        // 获取当前订单
        $order = request()->Model;
        // 演示数据，禁止操作
        // if (in_array($order->id,[256,275,285,302,317,79,148,149,186,221,222,236,244,245,268,282,283])) {
        // 	ApiException('演示数据，禁止操作');
        // }
        // 判断订单状态是否正确
        if ($order->refund_status !== 'applied') {
            ApiException('订单状态不正确');
        }
        $param = request()->param();
        // 是否同意退款
        if ($param['agree']) {
            // 同意
            $this->__refundOrder($order);
        } else {
            // 拒绝退款
            $order->extra = [
                'refund_reason'=> isset($order->extra->refund_reason) ? $order->extra->refund_reason: null,
                'refund_disagree_reason'=>$param['disagree_reason']
            ];
            $order->refund_status = 'pending';
            $order->save();
        }
        return showSuccess($order);
    }

    // 退款逻辑
    public function __refundOrder($order){
        switch ($order->payment_method) {
            case 'alipay':
                // 生成退款单号
                $refundNo = \app\model\admin\Order::setRefundOrderNo();
                // 调用支付宝退款
                $obj = new \app\controller\common\AliPay();
                $alipay = $obj->alipay;
                $res = $alipay->refund([
                    'out_trade_no' => $order->no, // 之前的订单流水号
                    'refund_amount' => $order->total_price, // 退款金额，单位元
                    'out_request_no' => $refundNo, // 退款订单号
                ]);
                // 根据支付宝的文档，如果返回值里有 sub_code 字段说明退款失败
                if ($res->sub_code) {
                    // 将订单的退款状态标记为退款失败
                    $order->refund_no = $refundNo;
                    $order->refund_status ='failed';
                    $order->extra =[
                        'refund_failed_code'=>$res->sub_code
                    ];
                    $order->save();
                } else {
                    // 将订单的退款状态标记为退款成功并保存退款订单号
                    $order->refund_no = $refundNo;
                    $order->refund_status ='success';
                    $order->save();
                }
                break;
            case 'wechat':
                // 生成退款单号
                $refundNo = \app\model\admin\Order::setRefundOrderNo();
                // 调用微信退款
                $obj = new \app\controller\common\wechatPay();
                $wechat = $obj->wechat;
                $res = $wechat->refund([
                	'type' => 'app',
                	'out_trade_no' => $order->no, // 之前的订单流水号
				    'out_refund_no' => $refundNo, // 退款订单号
				    'total_fee' => strval($order->total_price*100), // 退款金额，单位元
				    'refund_fee' => strval($order->total_price*100), // 退款金额，单位元
				    'refund_desc' => $order->extra->refund_reason,
                ]);
                if ($res->return_code !== 'SUCCESS') {
                    // 将订单的退款状态标记为退款失败
                    $order->refund_no = $refundNo;
                    $order->refund_status ='failed';
                    $order->extra =[
                        'refund_failed_code'=>$res->return_msg
                    ];
                    $order->save();
                } else {
                    // 将订单的退款状态标记为退款成功并保存退款订单号
                    $order->refund_no = $refundNo;
                    $order->refund_status ='success';
                    $order->save();
                }
                break;
        }
    }


	// 后台订单列表
	public function orderList(){
		$param = request()->param();
        $limit = intval(getValByKey('limit',$param,10));
        $tab = getValByKey('tab',$param,'all');
        $model = $this->M;
        // 订单类型
        switch ($tab) {
        	case 'nopay': // 待付款
        		$model = $this->M->where('closed',0)
        						->whereNull('payment_method');
        		break;
        	case 'noship': // 待发货
        		$model = $this->M->where('closed',0)
        						->whereNotNull('payment_method')
        						->where('ship_status','pending')
        						->where('refund_status','pending');
        		break;
        	case 'shiped': // 已发货
        		$model = $this->M->where('closed',0)
        						->whereNotNull('payment_method')
        						->where('ship_status','delivered')
        						->where('refund_status','pending');
        		break;
        	case 'received': // 已收货
        		$model = $this->M->where('closed',0)
        						->whereNotNull('payment_method')
        						->where('ship_status','received')
        						->where('refund_status','pending');
        		break;
        	case 'finish': // 已完成
        		$model = $this->M->where('closed',0)
        						->whereNotNull('payment_method')
        						->where('ship_status','received')
        						->where('refund_status','pending');
        		break;
        	case 'closed': // 已关闭
        		$model = $this->M->where('closed',1);
        		break;
        	case 'refunding': // 退款中
        		$model = $this->M->where('closed',0)
        						->where('refund_status','applied');
        		break;
        }
        // 搜索条件
        if (array_key_exists('starttime',$param) && array_key_exists('endtime',$param)) {
        	$model = $model->whereTime('create_time', 'between', [$param['starttime'], $param['endtime']]);
        }
        if (array_key_exists('no',$param)) {
        	$model = $model->where('no','like','%'.$param['no'].'%');
        }
        if (array_key_exists('name',$param)) {
        	$model = $model->where('address->name','like','%'.$param['name'].'%');
        }
        if (array_key_exists('phone',$param)) {
        	$model = $model->where('address->phone','like','%'.$param['phone'].'%');
        }
        
        $totalCount = $model->count();
        $list = $model->page($param['page'],$limit)
		        ->with([
		            'orderItems'=>function($query){
                		$query->field(['id','order_id','shop_id','goods_id','num','price','skus_type'])
                		->with([
	            			'goodsItem'=>function ($que){
	            				$que->field(['id','title','cover','sku_type']);
	            			},
	            			'goodsSkus'=>function($q){
        						$q->field(['id','skus']);
        					}
            			]);
                	},'user'])
		        ->order([ 'id'=>'desc' ])
				->select();
        return showSuccess([
        	'list'=>$list,
        	'totalCount'=>$totalCount
        ]);
	}


	// 批量删除
    public function deleteAll(){
        return showSuccess($this->M->MdeleteAll());
    }
    
    // 导出订单
    public function excelexport(){
    	
    	$param = request()->param();
        $tab = getValByKey('tab',$param,'all');
        $model = $this->M;
        // 订单类型
        switch ($tab) {
        	case 'nopay': // 待付款
        		$model = $this->M->where('closed',0)
        						->whereNull('payment_method');
        		break;
        	case 'noship': // 待发货
        		$model = $this->M->where('closed',0)
        						->whereNotNull('payment_method')
        						->where('ship_status','pending')
        						->where('refund_status','pending');
        		break;
        	case 'shiped': // 已发货
        		$model = $this->M->where('closed',0)
        						->whereNotNull('payment_method')
        						->where('ship_status','delivered')
        						->where('refund_status','pending');
        		break;
        	case 'received': // 已收货
        		$model = $this->M->where('closed',0)
        						->whereNotNull('payment_method')
        						->where('ship_status','received')
        						->where('refund_status','pending');
        		break;
        	case 'finish': // 已完成
        		$model = $this->M->where('closed',0)
        						->whereNotNull('payment_method')
        						->where('ship_status','received')
        						->where('refund_status','pending');
        		break;
        	case 'closed': // 已关闭
        		$model = $this->M->where('closed',1);
        		break;
        	case 'refunding': // 退款中
        		$model = $this->M->where('closed',0)
        						->where('refund_status','applied');
        		break;
        }
        // 搜索条件
        if (array_key_exists('starttime',$param) && array_key_exists('endtime',$param)) {
        	$model = $model->whereTime('create_time', 'between', [$param['starttime'], $param['endtime']]);
        }
        
        $list = $model->with(['orderItems.goodsItem','user'])
		        ->order([ 'id'=>'desc' ])
				->select();
		
		$arr = [];
		$list->each(function($item) use(&$arr){
			// 联系方式
			$address = $item->address ="地址：".$item->address->province.$item->address->city.$item->address->district.$item->address->address." \n 姓名：".$item->address->name." \n 手机：".$item->address->phone;
			// 订单商品
			$order_items = '';
			foreach ($item->order_items as $val){
				$order_items .= '商品：'.$val['goods_item']['title']."\n ";
				$order_items .= '数量：'.$val['num']."\n ";
				$order_items .= '价格：'.$val['price']."\n\n ";
			}
			// 支付情况
			$pay = '未支付';
			switch ($item->payment_method) {
				case 'wechat':
					$pay = "支付方式：微信支付 \n 支付时间：".date('Y-m-d H:m:s',$item->paid_time);
					break;
				case 'wechat':
					$pay = "支付宝支付 \n 支付时间：".date('Y-m-d H:m:s',$item->paid_time);
					break;
			}
			// 发后状态
			$ship = '待发货';
			if ($item->ship_status && $item->ship_data) {
				$ship = "快递公司：".$item->ship_data->express_company." \n快递单号：".$item->ship_data->express_no." \n发货时间：".date('Y-m-d H:m:s',$item->ship_data->express_time);
			}
			
			$arr[] = [
				'id'=>$item->id,
				'no'=>$item->no,
				'address'=>$item->address,
				'order_items'=>$order_items,
				'pay'=>$pay,
				'ship'=>$ship,
				'create_time'=>$item->create_time
			];
		});
    	
    	// [名称, 字段名, 类型, 类型规则]
		$header = [
		    ['订单ID', 'id', 'text'],
		    ['订单号', 'no', 'text'],
		    ['收货地址', 'address'], // 规则不填默认text
		    ['商品', 'order_items'],
		    ['支付情况', 'pay'],
		    ['发货情况', 'ship'],
		    ['下单时间', 'create_time'],
		];
		
		// 简单使用
		return Excel::exportData($arr, $header);
		
		// 定制 默认导出xlsx 支持 : xlsx/xls/html/csv
		// return Excel::exportData($list, $header, '测试', 'xlsx');
    }
}
