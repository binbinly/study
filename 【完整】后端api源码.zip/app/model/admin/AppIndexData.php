<?php

namespace app\model\admin;

use app\model\common\BaseModel;

class AppIndexData extends BaseModel
{
    //json字段
    protected $json = ['data'];
}
