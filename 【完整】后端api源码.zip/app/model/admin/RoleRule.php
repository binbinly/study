<?php

namespace app\model\admin;

use think\model\Pivot;

class RoleRule extends Pivot
{
    //
}
