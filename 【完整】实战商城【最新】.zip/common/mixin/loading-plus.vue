<template>
	<view class="position-fixed top-0 left-0 right-0 bottom-0 bg-white font-md d-flex a-center j-center main-text-color" style="z-index: 10000;">
		加载中...
	</view>
</template>

<script>
</script>

<style>
</style>
