<template>
	<view class="divider"></view>
</template>

<script>
</script>

<style>
	.divider{
		height: 18rpx;background-color: #F5F5F5;
	}
</style>
