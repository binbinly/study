'use strict';
const Controller = require('./base');
class SchoolController extends Controller {
    // 当前模型
    get model() {
            return this.app.model.School
        }
        // 验证规则
    get rules() {
        return {
            name: {
                type: 'string',
                required: true,
                desc: '网校标题'
            },
        }
    }
    // 列表相关配置
    async getListOptions() {
        let { ctx, app, service } = this;
        let currentUser = ctx.authUser;
        return {
            validate: {},
            options: {
                where: {
                    user_id: currentUser.id
                },
                order: [
                    ['id', 'DESC']
                ]
            }
        }
    }

    async beforeRead(opt) {
        let { app } = this
        opt.include = [{
            model: app.model.User,
            attributes: ['id', 'username', 'nickname', 'phone', 'email']
        }]
        return opt
    }

    async afterRead(data) {
        return data
    }

    // 新增之前数据处理
    async beforeSave(data) {
        return {
            ...data,
            user_id: this.ctx.authUser.id,
            appid: this.ctx.genID()
        }
    }
    // 新增之后
    async afterSave(data) {
        let { app, ctx } = this
        let currentUser = ctx.authUser;
        await app.model.Schoolstaff.create({
            user_id: currentUser.id,
            school_id: data.id,
            iscreator: 1
        })
        return data
    }
    // 更新之前查询
    async beforeUpdate() {
        let { ctx, app, service } = this;
        let currentUser = ctx.authUser;
        let { school_id } = ctx.header
        return await this.findOrFail(this.model, {
            id: school_id,
            user_id: currentUser.id
        })
    }
    // 删除之前
    async beforeDelete(where) {
        return {
            ...where,
            user_id: this.ctx.authUser.id
        }
    }
}

module.exports = SchoolController;