module.exports = {
    // 成功提示
    apiSuccess(data = '', msg = 'ok', code = 20000) {
        this.body = { msg, data, code };
        this.status = 200;
    },
    // 失败提示
    apiFail(data = '', msg = 'fail', code = 400) {
        this.body = { msg, data };
        this.status = code;
    },
    // 生成唯一id
    genID() {
        let d = new Date().getTime();
        let uuid = 'xxxxxxxxxxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return uuid;
    },
    // 是否是邮箱
    isEmail(val) {
        return (new RegExp(/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/)).test(val)
    },
    // 是否是手机号码
    isPhone(val) {
        return (new RegExp(/^[1][3,4,5,6,7,8,9][0-9]{9}$/)).test(val)
    }
}