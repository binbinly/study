'use strict';

const Service = require('egg').Service;

class ColumnService extends Service {
    // 当前网校下的指定专栏是否存在
    async isExist(id, school_id = 0) {
        let { ctx, app } = this;
        if (school_id == 0) {
            school_id = ctx.currentSchool.id
        }
        let d = await app.model.Column.findOne({
            where: {
                school_id,
                id
            }
        })
        if (!d) {
            ctx.throw(404, '专栏ID不存在')
        }

        return d
    }
}

module.exports = ColumnService;