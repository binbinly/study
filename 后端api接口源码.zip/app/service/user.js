'use strict';

const Service = require('egg').Service;

class UserService extends Service {
    // 过滤角色id
    async filterIds(ids) {
            let { app } = this;
            let rows = await app.model.User.findAll({
                where: {
                    id: ids
                },
                attributes: ['id']
            })
            rows = app.toArray(rows)

            return rows.map(item => item.id)
        }
        // 根据 关键词获取key
    getKeyByKeyword(val) {
            let { ctx } = this
            let k = {}
            if (ctx.isPhone(val)) {
                k = 'phone'
            } else if (ctx.isEmail(val)) {
                k = 'email'
            } else {
                k = 'username'
            }
            return k
        }
        // 根据 手机/邮箱/用户名查询用户是否存在
    async findByKeyword(val) {
            let { ctx, app } = this
            let k = this.getKeyByKeyword(val)

            let user = await this.findByKey(k, val, 1)
            if (!user) {
                ctx.throw(404, '该用户不存在')
            }
            return user
        }
        // 根据指定key值查询单个用户
    async findByKey(key = 'id', value = 0, status = false) {
        let { app } = this;
        let where = {}
        where[key] = value
        if (typeof status == 'number') {
            where.status = status
        }
        return await app.model.User.findOne({ where })
    }
    async isExist(id, status = false) {
        let { ctx, app } = this;
        let d = await this.findByKey('id', id, status)
        if (!d) {
            ctx.throw(404, '当前用户不存在或已被禁用')
        }
        return d
    }
}

module.exports = UserService;