// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdminAccess = require('../../../app/controller/admin/access');
import ExportAdminBase = require('../../../app/controller/admin/base');
import ExportAdminBbs = require('../../../app/controller/admin/bbs');
import ExportAdminBook = require('../../../app/controller/admin/book');
import ExportAdminBookDetail = require('../../../app/controller/admin/book_detail');
import ExportAdminCash = require('../../../app/controller/admin/cash');
import ExportAdminCashconfirm = require('../../../app/controller/admin/cashconfirm');
import ExportAdminColumn = require('../../../app/controller/admin/column');
import ExportAdminColumnCourse = require('../../../app/controller/admin/column_course');
import ExportAdminCommon = require('../../../app/controller/admin/common');
import ExportAdminCoupon = require('../../../app/controller/admin/coupon');
import ExportAdminCourse = require('../../../app/controller/admin/course');
import ExportAdminFlashsale = require('../../../app/controller/admin/flashsale');
import ExportAdminGroup = require('../../../app/controller/admin/group');
import ExportAdminOrder = require('../../../app/controller/admin/order');
import ExportAdminOrderItem = require('../../../app/controller/admin/order_item');
import ExportAdminPost = require('../../../app/controller/admin/post');
import ExportAdminPostComment = require('../../../app/controller/admin/post_comment');
import ExportAdminQuestion = require('../../../app/controller/admin/question');
import ExportAdminRenovation = require('../../../app/controller/admin/renovation');
import ExportAdminRole = require('../../../app/controller/admin/role');
import ExportAdminSchool = require('../../../app/controller/admin/school');
import ExportAdminSchoolstaff = require('../../../app/controller/admin/schoolstaff');
import ExportAdminSchoolUser = require('../../../app/controller/admin/school_user');
import ExportAdminTestpaper = require('../../../app/controller/admin/testpaper');
import ExportAdminUser = require('../../../app/controller/admin/user');
import ExportAdminUserHistory = require('../../../app/controller/admin/user_history');
import ExportAdminUserTest = require('../../../app/controller/admin/user_test');

declare module 'egg' {
  interface IController {
    admin: {
      access: ExportAdminAccess;
      base: ExportAdminBase;
      bbs: ExportAdminBbs;
      book: ExportAdminBook;
      bookDetail: ExportAdminBookDetail;
      cash: ExportAdminCash;
      cashconfirm: ExportAdminCashconfirm;
      column: ExportAdminColumn;
      columnCourse: ExportAdminColumnCourse;
      common: ExportAdminCommon;
      coupon: ExportAdminCoupon;
      course: ExportAdminCourse;
      flashsale: ExportAdminFlashsale;
      group: ExportAdminGroup;
      order: ExportAdminOrder;
      orderItem: ExportAdminOrderItem;
      post: ExportAdminPost;
      postComment: ExportAdminPostComment;
      question: ExportAdminQuestion;
      renovation: ExportAdminRenovation;
      role: ExportAdminRole;
      school: ExportAdminSchool;
      schoolstaff: ExportAdminSchoolstaff;
      schoolUser: ExportAdminSchoolUser;
      testpaper: ExportAdminTestpaper;
      user: ExportAdminUser;
      userHistory: ExportAdminUserHistory;
      userTest: ExportAdminUserTest;
    }
  }
}
