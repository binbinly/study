// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportCheckSchool = require('../../../app/middleware/check_school');
import ExportCheckStaffAuth = require('../../../app/middleware/check_staff_auth');
import ExportErrorHandler = require('../../../app/middleware/error_handler');
import ExportIsLogin = require('../../../app/middleware/is_login');

declare module 'egg' {
  interface IMiddleware {
    checkSchool: typeof ExportCheckSchool;
    checkStaffAuth: typeof ExportCheckStaffAuth;
    errorHandler: typeof ExportErrorHandler;
    isLogin: typeof ExportIsLogin;
  }
}
