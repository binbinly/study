// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAccess = require('../../../app/model/access');
import ExportBbs = require('../../../app/model/bbs');
import ExportBbsManager = require('../../../app/model/bbs_manager');
import ExportBook = require('../../../app/model/book');
import ExportBookDetail = require('../../../app/model/book_detail');
import ExportCash = require('../../../app/model/cash');
import ExportCashconfirm = require('../../../app/model/cashconfirm');
import ExportColumn = require('../../../app/model/column');
import ExportColumnCourse = require('../../../app/model/column_course');
import ExportCoupon = require('../../../app/model/coupon');
import ExportCourse = require('../../../app/model/course');
import ExportFlashsale = require('../../../app/model/flashsale');
import ExportGroup = require('../../../app/model/group');
import ExportLevel = require('../../../app/model/level');
import ExportOrder = require('../../../app/model/order');
import ExportOrderItem = require('../../../app/model/order_item');
import ExportPost = require('../../../app/model/post');
import ExportPostComment = require('../../../app/model/post_comment');
import ExportPostSupport = require('../../../app/model/post_support');
import ExportQuestion = require('../../../app/model/question');
import ExportRenovation = require('../../../app/model/renovation');
import ExportRole = require('../../../app/model/role');
import ExportRoleAccess = require('../../../app/model/role_access');
import ExportSchool = require('../../../app/model/school');
import ExportSchoolstaff = require('../../../app/model/schoolstaff');
import ExportSchoolUser = require('../../../app/model/school_user');
import ExportTestpaper = require('../../../app/model/testpaper');
import ExportTestpaperQuestion = require('../../../app/model/testpaper_question');
import ExportUser = require('../../../app/model/user');
import ExportUserHistory = require('../../../app/model/user_history');
import ExportUserTest = require('../../../app/model/user_test');

declare module 'egg' {
  interface IModel {
    Access: ReturnType<typeof ExportAccess>;
    Bbs: ReturnType<typeof ExportBbs>;
    BbsManager: ReturnType<typeof ExportBbsManager>;
    Book: ReturnType<typeof ExportBook>;
    BookDetail: ReturnType<typeof ExportBookDetail>;
    Cash: ReturnType<typeof ExportCash>;
    Cashconfirm: ReturnType<typeof ExportCashconfirm>;
    Column: ReturnType<typeof ExportColumn>;
    ColumnCourse: ReturnType<typeof ExportColumnCourse>;
    Coupon: ReturnType<typeof ExportCoupon>;
    Course: ReturnType<typeof ExportCourse>;
    Flashsale: ReturnType<typeof ExportFlashsale>;
    Group: ReturnType<typeof ExportGroup>;
    Level: ReturnType<typeof ExportLevel>;
    Order: ReturnType<typeof ExportOrder>;
    OrderItem: ReturnType<typeof ExportOrderItem>;
    Post: ReturnType<typeof ExportPost>;
    PostComment: ReturnType<typeof ExportPostComment>;
    PostSupport: ReturnType<typeof ExportPostSupport>;
    Question: ReturnType<typeof ExportQuestion>;
    Renovation: ReturnType<typeof ExportRenovation>;
    Role: ReturnType<typeof ExportRole>;
    RoleAccess: ReturnType<typeof ExportRoleAccess>;
    School: ReturnType<typeof ExportSchool>;
    Schoolstaff: ReturnType<typeof ExportSchoolstaff>;
    SchoolUser: ReturnType<typeof ExportSchoolUser>;
    Testpaper: ReturnType<typeof ExportTestpaper>;
    TestpaperQuestion: ReturnType<typeof ExportTestpaperQuestion>;
    User: ReturnType<typeof ExportUser>;
    UserHistory: ReturnType<typeof ExportUserHistory>;
    UserTest: ReturnType<typeof ExportUserTest>;
  }
}
