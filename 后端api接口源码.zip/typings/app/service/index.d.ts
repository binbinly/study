// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
type AnyClass = new (...args: any[]) => any;
type AnyFunc<T = any> = (...args: any[]) => T;
type CanExportFunc = AnyFunc<Promise<any>> | AnyFunc<IterableIterator<any>>;
type AutoInstanceType<T, U = T extends CanExportFunc ? T : T extends AnyFunc ? ReturnType<T> : T> = U extends AnyClass ? InstanceType<U> : U;
import ExportAccess = require('../../../app/service/access');
import ExportBbs = require('../../../app/service/bbs');
import ExportBook = require('../../../app/service/book');
import ExportCache = require('../../../app/service/cache');
import ExportCash = require('../../../app/service/cash');
import ExportColumn = require('../../../app/service/column');
import ExportCourse = require('../../../app/service/course');
import ExportQuestion = require('../../../app/service/question');
import ExportRole = require('../../../app/service/role');
import ExportSchool = require('../../../app/service/school');
import ExportSchoolstaff = require('../../../app/service/schoolstaff');
import ExportUser = require('../../../app/service/user');

declare module 'egg' {
  interface IService {
    access: AutoInstanceType<typeof ExportAccess>;
    bbs: AutoInstanceType<typeof ExportBbs>;
    book: AutoInstanceType<typeof ExportBook>;
    cache: AutoInstanceType<typeof ExportCache>;
    cash: AutoInstanceType<typeof ExportCash>;
    column: AutoInstanceType<typeof ExportColumn>;
    course: AutoInstanceType<typeof ExportCourse>;
    question: AutoInstanceType<typeof ExportQuestion>;
    role: AutoInstanceType<typeof ExportRole>;
    school: AutoInstanceType<typeof ExportSchool>;
    schoolstaff: AutoInstanceType<typeof ExportSchoolstaff>;
    user: AutoInstanceType<typeof ExportUser>;
  }
}
